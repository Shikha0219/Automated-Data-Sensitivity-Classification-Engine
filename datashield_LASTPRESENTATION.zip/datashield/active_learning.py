"""
active_learning.py
------------------
Active learning loop + automated retraining trigger.

Gaps this fixes:
  - "Active learning pipeline not done" (gap analysis: RISK item)
  - "Automated retraining trigger: MANUAL ONLY" (gap analysis: ARCH)

How it works:
  1. Every human override (POST /override) is written to the override log
     by api.py. That log is treated as a stream of high-value labeled
     examples (humans only correct what the model got wrong).
  2. This module exposes:
        get_review_queue()       — overrides that haven't been folded
                                   into the training set yet
        export_training_batch()  — emit a CSV ready for scripts/train_all.py
        check_retraining_trigger() — returns a recommendation:
                                     None | 'manual' | 'auto' | 'urgent'
  3. The trigger fires when ANY of:
        a) override_rate > 5% over the last N classifications  (PS KPI)
        b) >= 50 new overrides have accumulated since last train
        c) > 30 days since last retraining
  4. The recommendation is surfaced in the API (/mlops/retraining) and
     in the Streamlit "Metrics & Compliance" tab. Actual retraining is
     still launched explicitly (Constraint C4: training data labeling
     requires dual approval) — we never auto-train without a human click.
"""
from __future__ import annotations
import csv
import json
import os
from datetime import datetime, timezone, timedelta
from typing import List, Dict, Any, Optional

PROJECT_DIR = os.path.dirname(os.path.abspath(__file__))
LOGS_DIR = os.path.join(PROJECT_DIR, 'logs')
OVERRIDE_LOG = os.path.join(LOGS_DIR, 'overrides.jsonl')
AUDIT_LOG = os.path.join(LOGS_DIR, 'audit.jsonl')
TRAIN_STATE_PATH = os.path.join(LOGS_DIR, 'training_state.json')
ACTIVE_BATCH_DIR = os.path.join(LOGS_DIR, 'active_learning_batches')

os.makedirs(LOGS_DIR, exist_ok=True)
os.makedirs(ACTIVE_BATCH_DIR, exist_ok=True)


# ─────────────────────────────────────────────────────────────
# State persistence (last training timestamp + cursor into overrides)
# ─────────────────────────────────────────────────────────────

def _load_state() -> Dict[str, Any]:
    if not os.path.exists(TRAIN_STATE_PATH):
        return {
            'last_training_utc': None,
            'overrides_consumed': 0,    # how many override rows we've already used
            'last_check_utc': None,
        }
    try:
        with open(TRAIN_STATE_PATH, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {'last_training_utc': None, 'overrides_consumed': 0, 'last_check_utc': None}


def _save_state(state: Dict[str, Any]) -> None:
    with open(TRAIN_STATE_PATH, 'w', encoding='utf-8') as f:
        json.dump(state, f, indent=2, sort_keys=True)


# ─────────────────────────────────────────────────────────────
# Read-only helpers
# ─────────────────────────────────────────────────────────────

def _read_jsonl(path: str) -> List[Dict[str, Any]]:
    if not os.path.exists(path):
        return []
    out = []
    with open(path, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if line:
                try:
                    out.append(json.loads(line))
                except Exception:
                    pass
    return out


def get_review_queue() -> List[Dict[str, Any]]:
    """Return all overrides NOT yet folded into training."""
    state = _load_state()
    overrides = _read_jsonl(OVERRIDE_LOG)
    return overrides[state.get('overrides_consumed', 0):]


def count_pending() -> int:
    return len(get_review_queue())


# ─────────────────────────────────────────────────────────────
# Retraining trigger
# ─────────────────────────────────────────────────────────────

def _override_rate(window: int = 200) -> float:
    audit = _read_jsonl(AUDIT_LOG)
    if not audit:
        return 0.0
    last_audit = audit[-window:]
    overrides = _read_jsonl(OVERRIDE_LOG)
    audit_ids = {a.get('doc_id') for a in last_audit}
    matched = sum(1 for o in overrides if o.get('doc_id') in audit_ids)
    return matched / len(last_audit) if last_audit else 0.0


def check_retraining_trigger() -> Dict[str, Any]:
    """
    Return a structured trigger recommendation.
    Levels:
      none    — no action needed
      manual  — user may consider retraining at their convenience
      auto    — schedule retraining within 48h (PS Drift Alert SLA)
      urgent  — KPI breach (>5% override rate), retraining recommended ASAP
    """
    state = _load_state()
    state['last_check_utc'] = datetime.now(timezone.utc).isoformat()
    _save_state(state)

    pending = count_pending()
    override_rate = _override_rate(window=200)

    last_train = state.get('last_training_utc')
    if last_train:
        try:
            last_dt = datetime.fromisoformat(last_train.replace('Z', '+00:00'))
            days_since = (datetime.now(timezone.utc) - last_dt).days
        except Exception:
            days_since = None
    else:
        days_since = None

    reasons: List[str] = []
    level = 'none'

    if override_rate > 0.05:
        level = 'urgent'
        reasons.append(f'override_rate={override_rate:.3f} > 5% (PS KPI breach)')
    elif override_rate > 0.03:
        # 3% threshold = PS Drift Alert SLA
        level = 'auto'
        reasons.append(f'override_rate={override_rate:.3f} > 3% (PS Drift SLA)')

    if pending >= 50:
        level = 'auto' if level == 'none' else level
        reasons.append(f'{pending} pending overrides accumulated')

    if days_since is not None and days_since > 30:
        level = 'auto' if level == 'none' else level
        reasons.append(f'{days_since} days since last training')
    elif days_since is None:
        reasons.append('No training timestamp recorded yet')

    if level == 'none' and pending > 0:
        level = 'manual'
        reasons.append(f'{pending} new corrections available — may improve model')

    return {
        'level': level,
        'reasons': reasons,
        'pending_overrides': pending,
        'override_rate_recent': round(override_rate, 4),
        'days_since_last_training': days_since,
        'last_training_utc': last_train,
        'recommended_action': {
            'none': 'Continue monitoring.',
            'manual': 'Run retraining when convenient: python scripts/train_all.py',
            'auto': 'Retraining recommended within 48h (PS SLA).',
            'urgent': 'KPI breach. Run retraining ASAP after Legal+DataGov approval.',
        }[level],
    }


# ─────────────────────────────────────────────────────────────
# Export a training batch from pending overrides
# ─────────────────────────────────────────────────────────────

def export_training_batch(
    include_text: bool = False,
    augment_with_audit: bool = True,
) -> Optional[str]:
    """
    Write pending overrides as a CSV ready to be appended to the training
    set. Returns the CSV path, or None if nothing to export.

    Per Constraint C1 we never write raw PII to disk. The override log
    only contains the MASKED snippet from the audit log, so this is safe.

    When include_text=True we also include the masked input snippet in the
    'text' column so a human can review what they corrected before
    triggering a retrain (dual-approval workflow).
    """
    pending = get_review_queue()
    if not pending:
        return None

    timestamp = datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')
    out_path = os.path.join(ACTIVE_BATCH_DIR, f'training_batch_{timestamp}.csv')

    # Build an audit-id → snippet map so we can attach masked text
    snippet_map: Dict[str, str] = {}
    if include_text and augment_with_audit:
        for a in _read_jsonl(AUDIT_LOG):
            if a.get('doc_id'):
                snippet_map[a['doc_id']] = a.get('input_snippet_masked', '')

    with open(out_path, 'w', encoding='utf-8', newline='') as f:
        writer = csv.writer(f)
        header = ['doc_id', 'original_label', 'corrected_label', 'reviewer',
                  'reason', 'timestamp_utc']
        if include_text:
            header.append('masked_snippet')
        writer.writerow(header)

        for o in pending:
            row = [
                o.get('doc_id', ''),
                o.get('original_label', ''),
                o.get('corrected_label', ''),
                o.get('reviewer', ''),
                o.get('reason', ''),
                o.get('timestamp_utc', ''),
            ]
            if include_text:
                row.append(snippet_map.get(o.get('doc_id', ''), ''))
            writer.writerow(row)

    return out_path


def mark_consumed(up_to: Optional[int] = None) -> int:
    """
    Move the override cursor forward — call this AFTER a retraining run
    so the consumed overrides aren't re-exported next time.
    Returns the new cursor position.
    """
    state = _load_state()
    total = len(_read_jsonl(OVERRIDE_LOG))
    state['overrides_consumed'] = up_to if up_to is not None else total
    state['last_training_utc'] = datetime.now(timezone.utc).isoformat()
    _save_state(state)
    return state['overrides_consumed']


# ─────────────────────────────────────────────────────────────
# Summary for the metrics dashboard
# ─────────────────────────────────────────────────────────────

def summary() -> Dict[str, Any]:
    state = _load_state()
    trigger = check_retraining_trigger()
    return {
        'pending_overrides': count_pending(),
        'overrides_consumed': state.get('overrides_consumed', 0),
        'last_training_utc': state.get('last_training_utc'),
        'last_check_utc': state.get('last_check_utc'),
        'retraining_trigger': trigger,
    }
