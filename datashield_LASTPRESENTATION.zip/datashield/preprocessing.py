"""
preprocessing.py
----------------
PS-01 Layer 2: Pre-processing pipeline.

What this layer does (per problem statement):
  1. Text cleaning      — normalize whitespace, strip control chars, unicode normalize
  2. Boilerplate strip  — remove email headers/footers, common signatures
  3. PII masking        — Presidio (primary) + regex (fallback/defensive)
  4. Tokenization       — whitespace + simple punct split
  5. Chunking           — break long docs into manageable pieces
  6. Metadata extraction— infer source_system / department from text if not given
  7. Language detection — script-based EN/HI router (utils/language_detector.py)

Why a dedicated module instead of folding into pipeline.py:
  Pipeline used to do its preprocessing inline. The gap analysis flagged
  that PS-01 expects this as a separately addressable layer (auditable,
  testable, swappable). This module exposes:
      preprocess(text, metadata) -> PreprocessedDoc
  with everything traceable: the classifier sees the cleaned text, the
  audit log sees the masked text, the policy engine sees the RAW text
  (it needs the PII patterns to fire its overrides).
"""
from __future__ import annotations
import re
import unicodedata
from dataclasses import dataclass, field, asdict
from typing import Dict, Any, List, Tuple

from utils.language_detector import detect_language, language_label
from utils.presidio_masker import get_masker


# ─────────────────────────────────────────────────────────────
# Output schema
# ─────────────────────────────────────────────────────────────

@dataclass
class PreprocessedDoc:
    raw_text: str                       # original, untouched (for policy engine)
    clean_text: str                     # cleaned, normalized — what classifier sees
    masked_text: str                    # PII removed — what audit log sees
    detected_language: str              # 'en' | 'hi' | 'unknown'
    language_label: str                 # human-readable
    tokens: List[str]                   # cheap token list for downstream use
    chunks: List[str]                   # split into <=512 token chunks (transformer-ready)
    pii_entities: List[str]             # types found by masker
    char_count: int
    token_count: int
    chunk_count: int
    metadata: Dict[str, Any]            # original + inferred metadata

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    def for_audit(self) -> Dict[str, Any]:
        """Audit-safe view — never includes raw_text or clean_text."""
        return {
            'masked_text_preview': self.masked_text[:300] + ('...' if len(self.masked_text) > 300 else ''),
            'detected_language': self.detected_language,
            'language_label': self.language_label,
            'token_count': self.token_count,
            'chunk_count': self.chunk_count,
            'pii_entities': self.pii_entities,
            'metadata': {k: v for k, v in self.metadata.items() if k != 'raw_text'},
        }


# ─────────────────────────────────────────────────────────────
# Cleaning helpers
# ─────────────────────────────────────────────────────────────

_CONTROL_CHARS_RE = re.compile(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]')
_MULTISPACE_RE = re.compile(r'[ \t]+')
_MULTINEWLINE_RE = re.compile(r'\n{3,}')

# Common boilerplate that adds noise without signal
_BOILERPLATE_PATTERNS = [
    re.compile(r'(?im)^>\s.*$'),                                       # email quote lines
    re.compile(r'(?im)^[-_=]{4,}.*$'),                                 # separator lines
    re.compile(r'(?im)^(sent from my .+|get outlook for .+)$'),
    re.compile(r'(?im)^this email and any attachments are confidential.*$'),
    re.compile(r'(?im)^unsubscribe.*$'),
]


def _unicode_normalize(text: str) -> str:
    # NFKC keeps Hindi Devanagari but normalizes width / ligatures
    return unicodedata.normalize('NFKC', text)


def _strip_control_chars(text: str) -> str:
    return _CONTROL_CHARS_RE.sub(' ', text)


def _strip_boilerplate(text: str) -> str:
    for pat in _BOILERPLATE_PATTERNS:
        text = pat.sub('', text)
    return text


def _collapse_whitespace(text: str) -> str:
    text = _MULTISPACE_RE.sub(' ', text)
    text = _MULTINEWLINE_RE.sub('\n\n', text)
    return text.strip()


def clean_text(text: str) -> str:
    """The single cleaning entry point. Idempotent."""
    if not text:
        return ''
    t = _unicode_normalize(text)
    t = _strip_control_chars(t)
    t = _strip_boilerplate(t)
    t = _collapse_whitespace(t)
    return t


# ─────────────────────────────────────────────────────────────
# Tokenization & chunking
# ─────────────────────────────────────────────────────────────

_TOKEN_RE = re.compile(r"\w+(?:'\w+)?", flags=re.UNICODE)


def tokenize(text: str) -> List[str]:
    """Cheap, deterministic tokenizer. Works for both EN and HI."""
    if not text:
        return []
    return _TOKEN_RE.findall(text)


def chunk_text(text: str, max_tokens: int = 480) -> List[str]:
    """
    Split text into chunks of ~max_tokens. Used for long-document handling
    and for transformer batching (BERT family caps at 512 wordpieces).
    """
    if not text:
        return []
    paragraphs = [p.strip() for p in text.split('\n') if p.strip()]
    if not paragraphs:
        return [text]

    chunks: List[str] = []
    current: List[str] = []
    current_count = 0
    for para in paragraphs:
        n = len(tokenize(para))
        if current_count + n <= max_tokens or not current:
            current.append(para)
            current_count += n
        else:
            chunks.append('\n'.join(current))
            current = [para]
            current_count = n
    if current:
        chunks.append('\n'.join(current))
    return chunks


# ─────────────────────────────────────────────────────────────
# Metadata inference
# ─────────────────────────────────────────────────────────────

_SOURCE_HINTS = {
    'jira': 'JIRA', 'servicenow': 'ServiceNow', 'confluence': 'Confluence',
    'workday': 'Workday', 'salesforce': 'Salesforce', 'gmail': 'Gmail',
    'sharepoint': 'SharePoint',
}

_DEPT_HINTS = {
    'hr': 'HR', 'human resources': 'HR', 'finance': 'Finance', 'legal': 'Legal',
    'engineering': 'Engineering', 'sales': 'Sales', 'marketing': 'Marketing',
    'operations': 'Operations', 'compensation': 'HR', 'salary': 'HR',
    'invoice': 'Finance', 'contract': 'Legal',
}


def infer_metadata(text: str, given: Dict[str, Any]) -> Dict[str, Any]:
    """
    Fill in source_system / department if not provided. We use simple
    keyword hints — this is deliberately lightweight; the classifier
    learns the harder signals.
    """
    meta = dict(given or {})
    lower = (text or '')[:2000].lower()

    if 'source_system' not in meta or not meta.get('source_system'):
        for hint, val in _SOURCE_HINTS.items():
            if hint in lower:
                meta['source_system'] = val
                break

    if 'department' not in meta or not meta.get('department'):
        for hint, val in _DEPT_HINTS.items():
            if hint in lower:
                meta['department'] = val
                break

    meta.setdefault('source_system', 'UNKNOWN')
    meta.setdefault('department', 'UNKNOWN')
    meta.setdefault('file_type', meta.get('file_type', 'txt'))
    return meta


# ─────────────────────────────────────────────────────────────
# Main entry point
# ─────────────────────────────────────────────────────────────

def preprocess(text: str, metadata: Dict[str, Any] | None = None) -> PreprocessedDoc:
    """
    Run the full preprocessing pipeline on one document.
    Returns a PreprocessedDoc with everything traceable.
    """
    metadata = metadata or {}
    raw = text or ''

    # Step 1: clean
    cleaned = clean_text(raw)

    # Step 2: detect language (script-based)
    lang = detect_language(cleaned)

    # Step 3: mask PII (Presidio → fallback to regex)
    masker = get_masker()
    masked, pii_entities = masker.mask(cleaned)

    # Step 4: tokenize
    tokens = tokenize(cleaned)

    # Step 5: chunk
    chunks = chunk_text(cleaned)

    # Step 6: enrich metadata
    enriched_meta = infer_metadata(cleaned, metadata)
    enriched_meta['detected_language'] = lang

    return PreprocessedDoc(
        raw_text=raw,
        clean_text=cleaned,
        masked_text=masked,
        detected_language=lang,
        language_label=language_label(lang),
        tokens=tokens,
        chunks=chunks,
        pii_entities=pii_entities,
        char_count=len(cleaned),
        token_count=len(tokens),
        chunk_count=len(chunks),
        metadata=enriched_meta,
    )
