"""
ingestion.py
------------
Document ingestion layer: parse text from uploaded files of any format.
Supports: PDF, DOCX, TXT, MD, CSV, JSON, JSONL, HTML, RTF
No Kafka, no S3 — local file ingestion for laptop deployment.
"""
import os
import csv
import json
import io
from pathlib import Path
from typing import Tuple, Dict, Any, List, Optional

SUPPORTED_FORMATS = ['.pdf', '.docx', '.doc', '.txt', '.md', '.csv',
                     '.json', '.jsonl', '.html', '.htm', '.rtf', '.log']


def extract_text_from_file(file_path: str, filename: Optional[str] = None) -> Tuple[str, Dict[str, Any]]:
    """
    Extract text from a file path. Returns (text, metadata).
    """
    path = Path(file_path)
    ext = (filename or path.name).lower()
    ext = '.' + ext.rsplit('.', 1)[-1] if '.' in ext else path.suffix.lower()

    metadata = {
        'source_file': filename or path.name,
        'file_type': ext.lstrip('.'),
        'size_bytes': path.stat().st_size if path.exists() else 0,
    }

    try:
        if ext == '.pdf':
            text = _extract_pdf(file_path)
        elif ext in ('.docx',):
            text = _extract_docx(file_path)
        elif ext in ('.txt', '.md', '.log', '.rtf'):
            text = _extract_txt(file_path)
        elif ext in ('.html', '.htm'):
            text = _extract_html(file_path)
        elif ext == '.csv':
            text = _extract_csv(file_path)
        elif ext in ('.json', '.jsonl'):
            text = _extract_json(file_path)
        else:
            # Try as plain text
            text = _extract_txt(file_path)
    except Exception as e:
        text = f"[Extraction failed: {e}]"
        metadata['extraction_error'] = str(e)

    metadata['char_count'] = len(text)
    metadata['word_count'] = len(text.split())
    return text.strip(), metadata


def extract_text_from_bytes(file_bytes: bytes, filename: str) -> Tuple[str, Dict[str, Any]]:
    """
    Extract text from bytes (for Streamlit uploaded files).
    """
    ext = '.' + filename.rsplit('.', 1)[-1].lower() if '.' in filename else '.txt'
    metadata = {
        'source_file': filename,
        'file_type': ext.lstrip('.'),
        'size_bytes': len(file_bytes),
    }

    try:
        if ext == '.pdf':
            text = _extract_pdf_bytes(file_bytes)
        elif ext == '.docx':
            text = _extract_docx_bytes(file_bytes)
        elif ext in ('.html', '.htm'):
            text = _extract_html_bytes(file_bytes)
        elif ext == '.csv':
            text = _extract_csv_bytes(file_bytes)
        elif ext in ('.json', '.jsonl'):
            text = _extract_json_bytes(file_bytes)
        else:
            # Plain text
            text = file_bytes.decode('utf-8', errors='replace')
    except Exception as e:
        text = f"[Extraction failed: {e}]"
        metadata['extraction_error'] = str(e)

    metadata['char_count'] = len(text)
    metadata['word_count'] = len(text.split())
    return text.strip(), metadata


# ─────────────────────────────────────────────────────────────
# Format-specific extractors (file path)
# ─────────────────────────────────────────────────────────────

def _extract_pdf(path: str) -> str:
    try:
        import pdfplumber
        with pdfplumber.open(path) as pdf:
            pages = []
            for page in pdf.pages:
                t = page.extract_text()
                if t:
                    pages.append(t)
        return '\n'.join(pages)
    except ImportError:
        pass
    # Fallback: pypdf
    try:
        from pypdf import PdfReader
        reader = PdfReader(path)
        return '\n'.join(p.extract_text() or '' for p in reader.pages)
    except Exception as e:
        raise RuntimeError(f"PDF extraction failed: {e}")


def _extract_docx(path: str) -> str:
    from docx import Document
    doc = Document(path)
    return '\n'.join(p.text for p in doc.paragraphs if p.text.strip())


def _extract_txt(path: str) -> str:
    with open(path, 'r', encoding='utf-8', errors='replace') as f:
        return f.read()


def _extract_html(path: str) -> str:
    with open(path, 'r', encoding='utf-8', errors='replace') as f:
        content = f.read()
    return _html_to_text(content)


def _extract_csv(path: str) -> str:
    rows = []
    with open(path, 'r', encoding='utf-8', errors='replace', newline='') as f:
        reader = csv.DictReader(f)
        for row in reader:
            rows.append(' '.join(str(v) for v in row.values() if v))
    return '\n'.join(rows)


def _extract_json(path: str) -> str:
    with open(path, 'r', encoding='utf-8', errors='replace') as f:
        content = f.read()
    return _json_to_text(content)


# ─────────────────────────────────────────────────────────────
# Format-specific extractors (bytes)
# ─────────────────────────────────────────────────────────────

def _extract_pdf_bytes(data: bytes) -> str:
    buf = io.BytesIO(data)
    try:
        import pdfplumber
        with pdfplumber.open(buf) as pdf:
            pages = []
            for page in pdf.pages:
                t = page.extract_text()
                if t:
                    pages.append(t)
        return '\n'.join(pages)
    except ImportError:
        pass
    try:
        from pypdf import PdfReader
        buf.seek(0)
        reader = PdfReader(buf)
        return '\n'.join(p.extract_text() or '' for p in reader.pages)
    except Exception as e:
        raise RuntimeError(f"PDF extraction failed: {e}")


def _extract_docx_bytes(data: bytes) -> str:
    from docx import Document
    doc = Document(io.BytesIO(data))
    return '\n'.join(p.text for p in doc.paragraphs if p.text.strip())


def _extract_html_bytes(data: bytes) -> str:
    content = data.decode('utf-8', errors='replace')
    return _html_to_text(content)


def _extract_csv_bytes(data: bytes) -> str:
    content = data.decode('utf-8', errors='replace')
    rows = []
    reader = csv.DictReader(io.StringIO(content))
    for row in reader:
        rows.append(' '.join(str(v) for v in row.values() if v))
    return '\n'.join(rows)


def _extract_json_bytes(data: bytes) -> str:
    content = data.decode('utf-8', errors='replace')
    return _json_to_text(content)


# ─────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────

def _html_to_text(html: str) -> str:
    try:
        from bs4 import BeautifulSoup
        soup = BeautifulSoup(html, 'html.parser')
        return soup.get_text(separator=' ', strip=True)
    except ImportError:
        import re
        text = re.sub(r'<[^>]+>', ' ', html)
        return ' '.join(text.split())


def _json_to_text(content: str) -> str:
    parts = []
    try:
        data = json.loads(content)
        if isinstance(data, list):
            for item in data:
                if isinstance(item, dict):
                    parts.append(' '.join(str(v) for v in item.values()))
                else:
                    parts.append(str(item))
        elif isinstance(data, dict):
            parts.append(' '.join(str(v) for v in data.values()))
    except json.JSONDecodeError:
        # Try JSONL
        for line in content.strip().split('\n'):
            line = line.strip()
            if line:
                try:
                    obj = json.loads(line)
                    if isinstance(obj, dict):
                        parts.append(' '.join(str(v) for v in obj.values()))
                except Exception:
                    parts.append(line)
    return '\n'.join(parts)
