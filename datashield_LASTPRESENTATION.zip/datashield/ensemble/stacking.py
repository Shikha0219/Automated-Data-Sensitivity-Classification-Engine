"""
stacking.py
-----------
Stacking ensemble.

We train base models, get OUT-OF-FOLD predictions on training data (so the
meta-learner doesn't see leaked predictions), then train a meta-learner
(LogisticRegression by default) on the concatenated [n, n_models*n_classes]
feature matrix.

At inference: each base model predicts → we stack probabilities → meta
predicts the final class probabilities.

Why stacking over voting for this problem:
  - Different models have different error modes. LR is over-confident on
    keyword presence; XGBoost overfits to metadata; transformer smooths too
    much on short text. A meta-learner learns HOW to combine them rather
    than treating weights as static.
  - Trade-off: needs CV and a held-out set; more moving parts to audit.
"""
import os
from typing import List, Dict, Any, Optional
import joblib
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold


class StackingEnsemble:
    def __init__(self, classes: List[str], n_folds: int = 5, meta: str = 'logistic_regression'):
        self.classes = classes
        self.n_folds = n_folds
        self.meta_kind = meta
        self.meta_model = None
        self.active_model_names: List[str] = []   # order is fixed after fit

    def _build_meta(self):
        if self.meta_kind == 'logistic_regression':
            return LogisticRegression(max_iter=1000, C=1.0, class_weight='balanced', random_state=42)
        raise ValueError(f'Unknown meta learner: {self.meta_kind}')

    @staticmethod
    def _stack_features(model_probs: Dict[str, np.ndarray], model_order: List[str]) -> np.ndarray:
        """Concatenate model probability matrices horizontally."""
        return np.hstack([model_probs[name] for name in model_order])

    def fit_meta(
        self,
        oof_probs: Dict[str, np.ndarray],
        labels: np.ndarray,
    ):
        """
        oof_probs: dict model_name → (n, n_classes) OOF predictions
        labels: (n,) integer-encoded labels
        """
        self.active_model_names = sorted(oof_probs.keys())
        X_meta = self._stack_features(oof_probs, self.active_model_names)
        self.meta_model = self._build_meta()
        self.meta_model.fit(X_meta, labels)
        return self

    def predict_proba(self, model_probs: Dict[str, Optional[np.ndarray]]) -> np.ndarray:
        """
        model_probs: dict model_name → (n, n_classes) or None (model failed)
        If a model from training is missing at inference, we fill with uniform
        priors — the meta-learner still produces a prediction (graceful fallback).
        """
        if self.meta_model is None:
            raise RuntimeError('Stacking meta-model not fitted yet')

        n = next(iter(p.shape[0] for p in model_probs.values() if p is not None), 0)
        filled = {}
        for name in self.active_model_names:
            p = model_probs.get(name)
            if p is None:
                filled[name] = np.full((n, len(self.classes)), 1.0 / len(self.classes))
            else:
                filled[name] = p

        X_meta = self._stack_features(filled, self.active_model_names)
        probs = self.meta_model.predict_proba(X_meta)

        # Reorder meta model's class output to canonical order
        fitted = list(self.meta_model.classes_)
        reorder = [fitted.index(i) for i in range(len(self.classes))]
        return probs[:, reorder]

    def save(self, path: str):
        os.makedirs(os.path.dirname(path), exist_ok=True)
        joblib.dump({
            'meta_model': self.meta_model,
            'active_model_names': self.active_model_names,
            'classes': self.classes,
            'n_folds': self.n_folds,
            'meta_kind': self.meta_kind,
        }, path)

    @classmethod
    def load(cls, path: str) -> 'StackingEnsemble':
        obj = joblib.load(path)
        inst = cls(obj['classes'], obj['n_folds'], obj['meta_kind'])
        inst.meta_model = obj['meta_model']
        inst.active_model_names = obj['active_model_names']
        return inst


# -----------------------------------------------------------
# Utility: generate OOF predictions for stacking training.
# Used by scripts/train_all.py.
# -----------------------------------------------------------
def generate_oof_logistic(model_cls, cfg, classes, texts, labels, n_folds=5):
    """K-fold OOF probabilities for LogisticModel."""
    skf = StratifiedKFold(n_splits=n_folds, shuffle=True, random_state=42)
    labels_arr = np.array(labels)
    oof = np.zeros((len(texts), len(classes)), dtype=np.float32)
    for fold, (tr, va) in enumerate(skf.split(texts, labels_arr)):
        m = model_cls(cfg, classes)
        m.fit([texts[i] for i in tr], [labels[i] for i in tr])
        oof[va] = m.predict_proba([texts[i] for i in va])
    return oof


def generate_oof_xgboost(model_cls, cfg, classes, texts, labels, metadata, n_folds=5):
    """K-fold OOF probabilities for XGBoostModel."""
    skf = StratifiedKFold(n_splits=n_folds, shuffle=True, random_state=42)
    labels_arr = np.array(labels)
    oof = np.zeros((len(texts), len(classes)), dtype=np.float32)
    for fold, (tr, va) in enumerate(skf.split(texts, labels_arr)):
        m = model_cls(cfg, classes)
        m.fit(
            [texts[i] for i in tr],
            [labels[i] for i in tr],
            [metadata[i] for i in tr],
        )
        oof[va] = m.predict_proba(
            [texts[i] for i in va],
            [metadata[i] for i in va],
        )
    return oof


def generate_oof_transformer(model_cls, cfg, classes, texts, labels, n_folds=3):
    """
    K-fold OOF probabilities for TransformerModel.

    Uses fewer folds (default 3) than classical models because transformer
    training is expensive. Each fold fine-tunes the model from scratch to
    avoid data leakage.

    Returns (n, n_classes) OOF probability matrix.
    """
    skf = StratifiedKFold(n_splits=n_folds, shuffle=True, random_state=42)
    labels_arr = np.array(labels)
    oof = np.zeros((len(texts), len(classes)), dtype=np.float32)
    for fold, (tr, va) in enumerate(skf.split(texts, labels_arr)):
        print(f'  [transformer OOF] fold {fold + 1}/{n_folds}')
        m = model_cls(cfg, classes)
        m.fit(
            [texts[i] for i in tr],
            [labels[i] for i in tr],
        )
        oof[va] = m.predict_proba([texts[i] for i in va])
    return oof
