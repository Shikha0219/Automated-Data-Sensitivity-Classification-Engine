import { useEffect, useState } from 'react';
import { RefreshCw, FileSearch, Calendar, Eye } from 'lucide-react';
import { PageHeader, Card, SectionTitle, LabelBadge, ActionBadge, EmptyState, Spinner } from '../components/UI';
import { api, HistoryEntry } from '../lib/api';
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Cell, Tooltip } from 'recharts';
import PolicyTraceView from '../components/PolicyTraceView';

const LABEL_COLORS: Record<string, string> = {
  Public: '#10b981', Internal: '#3b82f6', Confidential: '#f59e0b', Restricted: '#ef4444',
};

export default function HistoryPage() {
  const [data, setData] = useState<{ total: number; entries: HistoryEntry[] } | null>(null);
  const [loading, setLoading] = useState(true);
  const [limit, setLimit] = useState(50);
  const [labelFilter, setLabelFilter] = useState('');
  const [onlyOverrides, setOnlyOverrides] = useState(false);
  const [selected, setSelected] = useState<string | null>(null);

  const load = async () => {
    setLoading(true);
    try {
      const r = await api.history({ limit, label: labelFilter, only_overrides: onlyOverrides });
      setData(r);
    } catch (e: any) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, [limit, labelFilter, onlyOverrides]);

  return (
    <div>
      <PageHeader
        title="Audit History"
        subtitle="Every classification, append-only with PII masked. Drill into any document for full lineage."
        action={
          <button onClick={load} className="btn-secondary">
            <RefreshCw className="w-4 h-4" /> Refresh
          </button>
        }
      />

      <Card className="mb-6">
        <div className="flex flex-wrap items-end gap-4">
          <div>
            <label className="label-text">Show last</label>
            <select className="input" value={limit} onChange={e => setLimit(Number(e.target.value))}>
              {[25, 50, 100, 200, 500].map(n => <option key={n} value={n}>{n}</option>)}
            </select>
          </div>
          <div>
            <label className="label-text">Label filter</label>
            <select className="input" value={labelFilter} onChange={e => setLabelFilter(e.target.value)}>
              <option value="">All labels</option>
              <option>Public</option><option>Internal</option><option>Confidential</option><option>Restricted</option>
            </select>
          </div>
          <label className="flex items-center gap-2 pb-2">
            <input type="checkbox" checked={onlyOverrides} onChange={e => setOnlyOverrides(e.target.checked)} className="rounded" />
            <span className="text-sm font-medium text-slate-700">Only overrides</span>
          </label>
          <div className="ml-auto text-xs text-slate-500">
            {data ? `${data.entries.length} of ${data.total} shown` : ''}
          </div>
        </div>
      </Card>

      {loading ? (
        <Card><div className="flex items-center justify-center py-8"><Spinner className="w-8 h-8" /></div></Card>
      ) : !data?.entries.length ? (
        <Card><EmptyState icon={FileSearch} title="No classifications yet" hint="Run some on the Classify page." /></Card>
      ) : (
        <div className="grid grid-cols-[1fr_1.4fr] gap-6">
          {/* List */}
          <Card className="!p-0 overflow-hidden">
            <div className="px-5 py-3 border-b border-slate-200">
              <SectionTitle>Documents</SectionTitle>
            </div>
            <div className="max-h-[600px] overflow-y-auto divide-y divide-slate-100">
              {data.entries.map(e => (
                <button
                  key={e.doc_id}
                  onClick={() => setSelected(e.doc_id)}
                  className={`w-full text-left px-5 py-3 hover:bg-slate-50 transition-colors ${selected === e.doc_id ? 'bg-brand-50/50 border-l-4 border-brand-500' : ''}`}
                >
                  <div className="flex items-center justify-between gap-2 mb-1">
                    <code className="text-xs font-mono text-slate-600 truncate">{e.doc_id}</code>
                    <LabelBadge label={e.label} />
                  </div>
                  <div className="flex items-center justify-between text-xs text-slate-500">
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3 h-3" />{e.timestamp_utc?.slice(0, 19).replace('T', ' ')}
                    </span>
                    <span>{(e.confidence * 100).toFixed(1)}%</span>
                  </div>
                  {e.human_override && (
                    <div className="text-xs text-violet-600 mt-1 font-medium">✏️ Has override</div>
                  )}
                </button>
              ))}
            </div>
          </Card>

          {/* Detail */}
          <div>
            {selected ? (
              <DocumentDetail docId={selected} onUpdate={load} />
            ) : (
              <Card><EmptyState icon={Eye} title="Pick a document" hint="Click one on the left to see the full audit record." /></Card>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

function DocumentDetail({ docId, onUpdate }: { docId: string; onUpdate: () => void }) {
  const [doc, setDoc] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [corrected, setCorrected] = useState('');
  const [reviewer, setReviewer] = useState('analyst@datashield');
  const [reason, setReason] = useState('');

  useEffect(() => {
    setLoading(true);
    api.document(docId).then(d => {
      setDoc(d);
      setCorrected(d.audit?.label || 'Internal');
    }).catch(console.error).finally(() => setLoading(false));
  }, [docId]);

  if (loading) return <Card><div className="flex items-center justify-center py-8"><Spinner /></div></Card>;
  if (!doc) return <Card>Document not found.</Card>;

  const audit = doc.audit;
  const probs = audit?.class_probabilities || {};
  const probData = ['Public', 'Internal', 'Confidential', 'Restricted'].map(l => ({ name: l, value: probs[l] || 0 }));

  const submit = async (action: 'confirm' | 'correct') => {
    setSubmitting(true);
    try {
      await api.override({
        doc_id: docId,
        original_label: audit.label,
        corrected_label: action === 'confirm' ? audit.label : corrected,
        reviewer,
        reason: reason || (action === 'confirm' ? 'confirmed correct' : ''),
      });
      const d = await api.document(docId);
      setDoc(d);
      setReason('');
      onUpdate();
    } catch (e: any) {
      alert('Failed: ' + e.message);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Card>
      <div className="flex items-center justify-between mb-4">
        <SectionTitle>Document Detail</SectionTitle>
        <code className="text-xs font-mono text-slate-500">{docId}</code>
      </div>

      <div className="space-y-4">
        <div className="flex items-center gap-3 flex-wrap">
          <LabelBadge label={audit.label} />
          <span className="text-sm font-medium">{(audit.confidence * 100).toFixed(1)}% confidence</span>
          <ActionBadge action={audit.policy_trace?.action} />
        </div>

        <div>
          <div className="text-xs font-semibold text-slate-600 uppercase tracking-wide mb-1">Masked input snippet</div>
          <pre className="bg-slate-50 border border-slate-200 rounded-lg p-3 text-xs font-mono whitespace-pre-wrap text-slate-700">
            {audit.input_snippet_masked || '(empty)'}
          </pre>
        </div>

        <div>
          <div className="text-xs font-semibold text-slate-600 uppercase tracking-wide mb-2">Class probabilities</div>
          <div className="h-28">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={probData} layout="vertical" margin={{ left: 0, right: 30 }}>
                <XAxis type="number" domain={[0, 1]} hide />
                <YAxis type="category" dataKey="name" width={90} tick={{ fontSize: 11 }} axisLine={false} tickLine={false} />
                <Tooltip formatter={(v: any) => `${(v * 100).toFixed(1)}%`} contentStyle={{ fontSize: 12 }} />
                <Bar dataKey="value" radius={[0, 4, 4, 0]}>
                  {probData.map(d => <Cell key={d.name} fill={LABEL_COLORS[d.name]} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <details className="border border-slate-200 rounded-lg overflow-hidden" open>
          <summary className="px-3 py-2 text-sm font-medium cursor-pointer bg-slate-50">Policy engine decision</summary>
          <div className="px-3 py-3">
            <PolicyTraceView trace={audit.policy_trace} />
          </div>
        </details>

        <details className="border border-slate-200 rounded-lg overflow-hidden">
          <summary className="px-3 py-2 text-sm font-medium cursor-pointer bg-slate-50">
            Overrides ({doc.overrides?.length || 0})
          </summary>
          <div className="px-3 py-2 space-y-2 max-h-48 overflow-y-auto">
            {doc.overrides?.length ? doc.overrides.map((o: any, i: number) => (
              <div key={i} className="text-xs">
                <div><strong>{o.reviewer}</strong>: {o.original_label} → {o.corrected_label}</div>
                <div className="text-slate-500">{o.reason} · {o.timestamp_utc}</div>
              </div>
            )) : <div className="text-sm text-slate-500">None</div>}
          </div>
        </details>

        <details className="border border-slate-200 rounded-lg overflow-hidden">
          <summary className="px-3 py-2 text-sm font-medium cursor-pointer bg-slate-50">
            Approvals ({doc.approvals?.length || 0})
          </summary>
          <div className="px-3 py-2 space-y-2 max-h-48 overflow-y-auto">
            {doc.approvals?.length ? doc.approvals.map((a: any, i: number) => (
              <div key={i} className="text-xs">
                <div><strong>{a.approver}</strong> · {a.decision}</div>
                <div className="text-slate-500">{a.notes} · {a.timestamp_utc}</div>
              </div>
            )) : <div className="text-sm text-slate-500">None</div>}
          </div>
        </details>

        <div className="border-t border-slate-200 pt-4">
          <div className="text-sm font-semibold text-slate-700 mb-3">Submit Human Review</div>
          <div className="grid grid-cols-2 gap-3 mb-3">
            <div>
              <label className="label-text">Reviewer</label>
              <input className="input" value={reviewer} onChange={e => setReviewer(e.target.value)} />
            </div>
            <div>
              <label className="label-text">Corrected label</label>
              <select className="input" value={corrected} onChange={e => setCorrected(e.target.value)}>
                <option>Public</option><option>Internal</option><option>Confidential</option><option>Restricted</option>
              </select>
            </div>
          </div>
          <textarea className="input mb-3" rows={2} placeholder="Reason / notes…" value={reason} onChange={e => setReason(e.target.value)} />
          <div className="flex gap-2">
            <button onClick={() => submit('confirm')} disabled={submitting} className="btn-secondary flex-1">Confirm Correct</button>
            <button onClick={() => submit('correct')} disabled={submitting || corrected === audit.label} className="btn-primary flex-1">Submit Correction</button>
          </div>
        </div>
      </div>
    </Card>
  );
}
