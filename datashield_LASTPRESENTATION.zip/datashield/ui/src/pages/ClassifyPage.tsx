import { useEffect, useRef, useState } from 'react';
import {
  Upload, FileText, FolderTree, FileArchive, Send, X, FileQuestion, RefreshCw,
} from 'lucide-react';
import {
  PageHeader, Card, SectionTitle, Spinner, EmptyState,
  ProgressBar, LabelBadge, ActionBadge, StatusDot,
} from '../components/UI';
import ResultCard from '../components/ResultCard';
import { api, ClassifyResponse, BatchJobStatus } from '../lib/api';

type Mode = 'upload' | 'paste' | 'batch';

const SAMPLES: Record<string, string> = {
  Public: 'Our Q1 product roadmap is published on the company website and open to all stakeholders. View it at https://example.com/roadmap.',
  Internal: 'All employees: please join the all-hands meeting Tuesday at 3pm in Conference Room A. Agenda attached.',
  Confidential: 'Employee ID 10293 — salary band L5 ($142,000). Performance review scheduled with HR next week.',
  Restricted: 'Customer SSN 123-45-6789, credit card 4111-1111-1111-1111 on file. GDPR data subject access request pending.',
};

const SOURCES = ['', 'JIRA', 'ServiceNow', 'Confluence', 'Workday', 'Salesforce', 'Gmail', 'SharePoint'];
const DEPTS = ['', 'Engineering', 'HR', 'Finance', 'Legal', 'Sales', 'Marketing', 'Operations'];

export default function ClassifyPage({ onResult }: { onResult?: (r: any) => void } = {}) {
  const [mode, setMode] = useState<Mode>('upload');

  return (
    <div>
      <PageHeader
        title="Classify Documents"
        subtitle="Submit a single file, paste text, or run an async batch over folders and ZIP archives."
      />

      {/* Mode tabs — sober pill style */}
      <div className="flex items-center gap-1 mb-6 bg-slate-100 p-1 rounded-md w-fit">
        <TabButton active={mode === 'upload'} onClick={() => setMode('upload')}>Upload</TabButton>
        <TabButton active={mode === 'paste'} onClick={() => setMode('paste')}>Paste text</TabButton>
        <TabButton active={mode === 'batch'} onClick={() => setMode('batch')}>Async batch</TabButton>
      </div>

      {mode === 'upload' && <UploadMode onResult={onResult} />}
      {mode === 'paste' && <PasteMode onResult={onResult} />}
      {mode === 'batch' && <BatchMode />}
    </div>
  );
}

function TabButton({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      onClick={onClick}
      className={`px-3.5 py-1.5 text-sm font-medium rounded transition-colors ${
        active ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-slate-900'
      }`}
    >
      {children}
    </button>
  );
}

// ──────────────────────────────────────────────────────────
// Upload mode (single + multi file)
// ──────────────────────────────────────────────────────────
function UploadMode({ onResult }: { onResult?: (r: any) => void }) {
  const [files, setFiles] = useState<File[]>([]);
  const [docId, setDocId] = useState('');
  const [source, setSource] = useState('');
  const [dept, setDept] = useState('');
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<ClassifyResponse[]>([]);
  const [errors, setErrors] = useState<string[]>([]);

  const onDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const dropped = Array.from(e.dataTransfer.files);
    setFiles(prev => [...prev, ...dropped]);
  };

  const onPick = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) setFiles(prev => [...prev, ...Array.from(e.target.files!)]);
    e.target.value = '';
  };

  const remove = (i: number) => setFiles(files.filter((_, idx) => idx !== i));

  const classify = async () => {
    if (!files.length) return;
    setLoading(true);
    setResults([]);
    setErrors([]);
    const out: ClassifyResponse[] = [];
    const errs: string[] = [];
    for (const f of files) {
      try {
        const opts: any = { source_system: source || undefined, department: dept || undefined };
        if (files.length === 1 && docId) opts.doc_id = docId;
        const r = await api.classifyFile(f, opts);
        out.push(r);
      } catch (e: any) {
        errs.push(`${f.name}: ${e.message}`);
      }
    }
    setResults(out);
    if (out.length > 0) onResult?.(out[0]);
    setErrors(errs);
    setLoading(false);
  };

  return (
    <div className="space-y-5">
      <Card>
        <div className="grid grid-cols-3 gap-4 mb-4">
          <div>
            <label className="label-text">Source system</label>
            <select className="input" value={source} onChange={e => setSource(e.target.value)}>
              {SOURCES.map(s => <option key={s} value={s}>{s || 'None'}</option>)}
            </select>
          </div>
          <div>
            <label className="label-text">Department</label>
            <select className="input" value={dept} onChange={e => setDept(e.target.value)}>
              {DEPTS.map(d => <option key={d} value={d}>{d || 'None'}</option>)}
            </select>
          </div>
          <div>
            <label className="label-text">Document ID (optional)</label>
            <input
              className="input font-mono text-xs"
              placeholder="auto-generated"
              value={docId}
              onChange={e => setDocId(e.target.value)}
            />
          </div>
        </div>

        <div
          onDrop={onDrop}
          onDragOver={(e) => e.preventDefault()}
          className="border border-dashed border-slate-300 rounded-md p-8 text-center bg-slate-50/30 hover:bg-slate-50/60 transition-colors"
        >
          <Upload className="w-7 h-7 mx-auto text-slate-400 mb-2" strokeWidth={1.5} />
          <p className="text-sm font-medium text-slate-700 mb-1">Drop files here or click to select</p>
          <p className="text-xs text-slate-500 mb-3">Supports PDF, DOCX, TXT, CSV, JSON, MD, HTML, LOG</p>
          <label className="btn-secondary cursor-pointer inline-flex">
            Select files
            <input
              type="file"
              multiple
              className="hidden"
              accept=".pdf,.docx,.txt,.csv,.json,.md,.html,.log,.jsonl"
              onChange={onPick}
            />
          </label>
        </div>

        {files.length > 0 && (
          <div className="mt-4 space-y-1.5">
            {files.map((f, i) => (
              <div key={i} className="flex items-center justify-between bg-slate-50 border border-slate-200 rounded px-3 py-2 text-sm">
                <div className="flex items-center gap-2 min-w-0">
                  <FileText className="w-4 h-4 text-slate-400 flex-shrink-0" strokeWidth={1.5} />
                  <span className="truncate text-slate-700">{f.name}</span>
                  <span className="text-xs text-slate-400 flex-shrink-0">{(f.size / 1024).toFixed(1)} KB</span>
                </div>
                <button onClick={() => remove(i)} className="text-slate-400 hover:text-rose-600">
                  <X className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        )}

        <div className="mt-5 flex justify-end">
          <button onClick={classify} disabled={!files.length || loading} className="btn-primary">
            {loading ? <Spinner /> : <Send className="w-4 h-4" />}
            Classify {files.length > 0 ? `${files.length} file${files.length > 1 ? 's' : ''}` : ''}
          </button>
        </div>
      </Card>

      {errors.length > 0 && (
        <Card className="border-rose-200 bg-rose-50/50">
          <SectionTitle>Errors</SectionTitle>
          {errors.map((e, i) => <div key={i} className="text-sm text-rose-700">{e}</div>)}
        </Card>
      )}

      {results.length > 0 && (
        <div className="space-y-4 fade-in">
          {results.map((r, i) => <ResultCard key={i} result={r} />)}
        </div>
      )}
    </div>
  );
}

// ──────────────────────────────────────────────────────────
// Paste mode
// ──────────────────────────────────────────────────────────
function PasteMode({ onResult }: { onResult?: (r: any) => void }) {
  const [text, setText] = useState('');
  const [source, setSource] = useState('');
  const [dept, setDept] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<ClassifyResponse | null>(null);

  const classify = async () => {
    if (!text.trim()) return;
    setLoading(true);
    try {
      const r = await api.classifyText(text, { source_system: source || undefined, department: dept || undefined });
      setResult(r);
      onResult?.(r);
    } catch (e: any) {
      alert('Classify failed: ' + e.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-5">
      <Card>
        <div className="grid grid-cols-3 gap-4 mb-4">
          <div>
            <label className="label-text">Source system</label>
            <select className="input" value={source} onChange={e => setSource(e.target.value)}>
              {SOURCES.map(s => <option key={s} value={s}>{s || 'None'}</option>)}
            </select>
          </div>
          <div>
            <label className="label-text">Department</label>
            <select className="input" value={dept} onChange={e => setDept(e.target.value)}>
              {DEPTS.map(d => <option key={d} value={d}>{d || 'None'}</option>)}
            </select>
          </div>
          <div>
            <label className="label-text">Try a sample</label>
            <select
              className="input"
              onChange={e => e.target.value && setText(SAMPLES[e.target.value])}
              defaultValue=""
            >
              <option value="">Choose sample…</option>
              {Object.keys(SAMPLES).map(k => <option key={k} value={k}>{k}</option>)}
            </select>
          </div>
        </div>

        <label className="label-text">Document text</label>
        <textarea
          rows={9}
          className="input font-mono text-sm"
          placeholder="Paste customer ticket, email, HR record, financial doc…"
          value={text}
          onChange={e => setText(e.target.value)}
        />
        <div className="text-xs text-slate-500 mt-1.5">{text.length} chars · {text.split(/\s+/).filter(Boolean).length} tokens</div>

        <div className="mt-4 flex justify-end gap-2">
          <button className="btn-secondary" onClick={() => { setText(''); setResult(null); }} disabled={loading}>
            Clear
          </button>
          <button onClick={classify} disabled={!text.trim() || loading} className="btn-primary">
            {loading ? <Spinner /> : <Send className="w-4 h-4" />}
            Classify
          </button>
        </div>
      </Card>

      {result && <ResultCard result={result} />}
    </div>
  );
}

// ──────────────────────────────────────────────────────────
// Async batch mode — folders, ZIPs, auto-polling, per-file status
// ──────────────────────────────────────────────────────────
function BatchMode() {
  const [files, setFiles] = useState<File[]>([]);
  const [jobId, setJobId] = useState<string | null>(null);
  const [status, setStatus] = useState<BatchJobStatus | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [expandedFromZip, setExpandedFromZip] = useState<number>(0);
  const pollTimer = useRef<number | null>(null);

  // Auto-poll while job is queued/running
  useEffect(() => {
    if (!jobId) return;
    let cancelled = false;
    const tick = async () => {
      try {
        const s = await api.jobStatus(jobId);
        if (cancelled) return;
        setStatus(s);
        if (s.status === 'completed' || s.status === 'failed') {
          if (pollTimer.current) {
            window.clearInterval(pollTimer.current);
            pollTimer.current = null;
          }
        }
      } catch {
        /* ignore transient errors */
      }
    };
    tick();
    pollTimer.current = window.setInterval(tick, 1500);
    return () => {
      cancelled = true;
      if (pollTimer.current) window.clearInterval(pollTimer.current);
    };
  }, [jobId]);

  const onPickFiles = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) setFiles(prev => [...prev, ...Array.from(e.target.files!)]);
    e.target.value = '';
  };
  const remove = (i: number) => setFiles(files.filter((_, idx) => idx !== i));

  const submit = async () => {
    if (!files.length) return;
    setSubmitting(true);
    try {
      const r = await api.classifyBatch(files);
      setJobId(r.job_id);
      setStatus(null);
      setExpandedFromZip(r.expanded_from_zip || 0);
    } catch (e: any) {
      alert('Submit failed: ' + e.message);
    } finally {
      setSubmitting(false);
    }
  };

  const reset = () => {
    if (pollTimer.current) window.clearInterval(pollTimer.current);
    pollTimer.current = null;
    setJobId(null);
    setStatus(null);
    setFiles([]);
    setExpandedFromZip(0);
  };

  // Group files by their top-level folder (if any) for display
  const grouped = groupByFolder(files);

  return (
    <div className="space-y-5">
      {/* Upload sources */}
      <Card>
        <SectionTitle hint="Pick any combination of single files, an entire folder, or a ZIP archive. ZIPs are expanded recursively on the server.">
          Add documents
        </SectionTitle>

        <div className="grid grid-cols-3 gap-3">
          <SourceTile
            icon={FileText}
            title="Files"
            hint="Multiple files OK"
            accept=".pdf,.docx,.txt,.csv,.json,.md,.html,.htm,.log,.jsonl,.zip"
            onPick={onPickFiles}
          />
          <SourceTile
            icon={FolderTree}
            title="Folder"
            hint="Recursive scan"
            directory
            onPick={onPickFiles}
          />
          <SourceTile
            icon={FileArchive}
            title="ZIP archive"
            hint="Auto-extracted server-side"
            accept=".zip"
            onPick={onPickFiles}
          />
        </div>

        {files.length > 0 && (
          <div className="mt-5 border border-slate-200 rounded-md overflow-hidden">
            <div className="bg-slate-50 px-3 py-2 flex items-center justify-between border-b border-slate-200">
              <span className="text-xs font-semibold text-slate-700 tracking-wide uppercase">
                {files.length} item{files.length > 1 ? 's' : ''} staged
              </span>
              <button onClick={() => setFiles([])} className="text-xs text-slate-500 hover:text-rose-600 font-medium">
                Clear all
              </button>
            </div>
            <div className="max-h-64 overflow-y-auto">
              {grouped.map((g, gi) => (
                <div key={gi}>
                  {g.folder && (
                    <div className="px-3 py-1.5 bg-slate-50/60 text-[11px] font-semibold tracking-wide uppercase text-slate-500 border-b border-slate-100">
                      <FolderTree className="w-3 h-3 inline mr-1.5" strokeWidth={2} />
                      {g.folder}  <span className="text-slate-400 normal-case">({g.entries.length} file{g.entries.length > 1 ? 's' : ''})</span>
                    </div>
                  )}
                  {g.entries.map(({ f, idx }) => (
                    <div key={idx} className="flex items-center justify-between px-3 py-1.5 text-sm border-b border-slate-100 last:border-0">
                      <div className="flex items-center gap-2 min-w-0">
                        {f.name.toLowerCase().endsWith('.zip')
                          ? <FileArchive className="w-3.5 h-3.5 text-amber-600 flex-shrink-0" strokeWidth={1.8} />
                          : <FileText className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" strokeWidth={1.5} />
                        }
                        <span className="truncate text-slate-700">{(f as any).webkitRelativePath || f.name}</span>
                        <span className="text-[11px] text-slate-400 flex-shrink-0">{(f.size / 1024).toFixed(1)} KB</span>
                      </div>
                      <button onClick={() => remove(idx)} className="text-slate-400 hover:text-rose-600">
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="mt-5 flex items-center justify-between">
          <p className="text-xs text-slate-500">
            Processing is asynchronous. Job status streams below in real time.
          </p>
          <button onClick={submit} disabled={!files.length || submitting} className="btn-primary">
            {submitting ? <Spinner /> : <Send className="w-4 h-4" />}
            Submit batch
          </button>
        </div>
      </Card>

      {/* Job status */}
      {jobId && (
        <Card>
          <div className="flex items-center justify-between mb-4">
            <SectionTitle>Job status</SectionTitle>
            <div className="flex items-center gap-2">
              {status?.status !== 'completed' && status?.status !== 'failed' && (
                <span className="chip">
                  <Spinner className="w-3 h-3" /> Polling every 1.5s
                </span>
              )}
              <button onClick={reset} className="btn-ghost text-xs">
                <RefreshCw className="w-3.5 h-3.5" /> New job
              </button>
            </div>
          </div>

          {!status ? (
            <div className="text-sm text-slate-500 py-2">Loading status…</div>
          ) : (
            <>
              <div className="flex items-center gap-4 mb-3">
                <span className={`pill ${
                  status.status === 'completed' ? 'label-public' :
                  status.status === 'failed' ? 'label-restricted' : 'label-internal'
                }`}>
                  {status.status}
                </span>
                <span className="text-sm tabular-nums text-slate-700">
                  {status.progress.completed} / {status.progress.total} done
                  {status.progress.failed > 0 && (
                    <span className="text-rose-600 ml-2">· {status.progress.failed} failed</span>
                  )}
                </span>
                {expandedFromZip > 0 && (
                  <span className="chip">
                    <FileArchive className="w-3 h-3" /> {expandedFromZip} extracted from ZIP
                  </span>
                )}
                <code className="text-[11px] font-mono text-slate-500 ml-auto">{jobId.slice(0, 18)}</code>
              </div>

              <ProgressBar
                value={status.progress.completed}
                max={status.progress.total}
                tone={status.progress.failed > 0 ? 'danger' : 'brand'}
              />

              {/* Per-file table */}
              {status.files?.length > 0 && (
                <div className="mt-5 border border-slate-200 rounded-md overflow-hidden">
                  <table className="w-full text-sm">
                    <thead className="table-head">
                      <tr>
                        <th className="px-3 py-2 text-left">File</th>
                        <th className="px-3 py-2 text-left w-32">Status</th>
                        <th className="px-3 py-2 text-left w-28">Label</th>
                        <th className="px-3 py-2 text-left w-24">Confidence</th>
                        <th className="px-3 py-2 text-left w-28">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {status.files.map((f, i) => (
                        <tr key={i} className="hover:bg-slate-50/60">
                          <td className="px-3 py-2 font-mono text-xs text-slate-700 truncate max-w-md" title={f.source_file}>
                            {f.source_file}
                          </td>
                          <td className="px-3 py-2"><StatusDot status={f.status} /></td>
                          <td className="px-3 py-2">
                            {f.label ? <LabelBadge label={f.label} /> : <span className="text-slate-300">—</span>}
                          </td>
                          <td className="px-3 py-2 tabular-nums text-xs text-slate-700">
                            {f.confidence != null ? `${(f.confidence * 100).toFixed(1)}%` : '—'}
                          </td>
                          <td className="px-3 py-2">
                            {f.policy_action
                              ? <ActionBadge action={f.policy_action} />
                              : f.error
                                ? <span className="text-xs text-rose-600" title={f.error}>error</span>
                                : <span className="text-slate-300">—</span>
                            }
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </>
          )}
        </Card>
      )}

      {!jobId && files.length === 0 && (
        <EmptyState
          icon={FileQuestion}
          title="No batch in flight"
          hint="Add files, a folder, or a ZIP archive above to start."
        />
      )}
    </div>
  );
}

// ──────────────────────────────────────────────────────────
// Helpers
// ──────────────────────────────────────────────────────────

function SourceTile({
  icon: Icon, title, hint, accept, directory, onPick,
}: {
  icon: React.ComponentType<{ className?: string; strokeWidth?: number }>;
  title: string;
  hint: string;
  accept?: string;
  directory?: boolean;
  onPick: (e: React.ChangeEvent<HTMLInputElement>) => void;
}) {
  const extra: any = directory ? { webkitdirectory: '', directory: '' } : {};
  return (
    <label className="cursor-pointer border border-slate-200 hover:border-slate-300 hover:bg-slate-50/60 rounded-md p-4 text-center transition-colors">
      <Icon className="w-6 h-6 mx-auto text-slate-500 mb-2" strokeWidth={1.5} />
      <div className="text-sm font-medium text-slate-800">{title}</div>
      <div className="text-[11px] text-slate-500 mt-0.5">{hint}</div>
      <input
        type="file"
        multiple
        className="hidden"
        accept={accept}
        onChange={onPick}
        {...extra}
      />
    </label>
  );
}

function groupByFolder(files: File[]): { folder: string | null; entries: { f: File; idx: number }[] }[] {
  const groups = new Map<string, { f: File; idx: number }[]>();
  files.forEach((f, idx) => {
    const rel = (f as any).webkitRelativePath as string | undefined;
    const folder = rel && rel.includes('/') ? rel.split('/')[0] : '';
    const key = folder || '';
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key)!.push({ f, idx });
  });
  return Array.from(groups.entries()).map(([k, entries]) => ({
    folder: k || null,
    entries,
  }));
}
