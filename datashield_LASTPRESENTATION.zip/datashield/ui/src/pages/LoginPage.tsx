import { useState } from 'react';
import { ShieldCheck, Eye, EyeOff, Lock, Mail, User, ArrowRight } from 'lucide-react';

interface Props {
  onLogin: (user: { name: string; email: string; role: string }) => void;
}

const BUILTIN_USERS = [
  { email: 'shikha@datashield.io',  password: 'admin123',   name: 'Shikha B',        role: 'Admin'    },
  { email: 'akshay@datashield.io',  password: 'review123',  name: 'Akshay Choudhri', role: 'Reviewer' },
  { email: 'aditi@datashield.io',   password: 'analyst123', name: 'Aditi J',          role: 'Analyst'  },
];

const DS_USERS_KEY = 'ds_registered_users';

// Alias used in the login form's "Demo accounts" section
const DEMO_USERS = BUILTIN_USERS;

function getAllUsers() {
  try {
    const saved = JSON.parse(localStorage.getItem(DS_USERS_KEY) || '[]');
    return [...BUILTIN_USERS, ...saved];
  } catch { return BUILTIN_USERS; }
}

function saveNewUser(u: { email: string; password: string; name: string; role: string }) {
  try {
    const saved = JSON.parse(localStorage.getItem(DS_USERS_KEY) || '[]');
    saved.push(u);
    localStorage.setItem(DS_USERS_KEY, JSON.stringify(saved));
  } catch {}
}

const roleColor = (r: string) =>
  r === 'Admin'    ? 'bg-violet-100 text-violet-700 border-violet-200' :
  r === 'Reviewer' ? 'bg-amber-100 text-amber-700 border-amber-200'   :
                     'bg-blue-100 text-blue-700 border-blue-200';

export default function LoginPage({ onLogin }: Props) {
  const [mode, setMode]             = useState<'login' | 'signup'>('login');
  const [email, setEmail]           = useState('');
  const [password, setPassword]     = useState('');
  const [name, setName]             = useState('');
  const [role, setRole]             = useState('Analyst');
  const [showPw, setShowPw]         = useState(false);
  const [error, setError]           = useState('');
  const [loading, setLoading]       = useState(false);
  const [signupDone, setSignupDone] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault(); setError(''); setLoading(true);
    await new Promise(r => setTimeout(r, 600));
    const found = getAllUsers().find(u => u.email === email && u.password === password);
    if (found) {
      const normalizedRole = found.role?.trim() ?? found.role;
      localStorage.setItem('ds_user', JSON.stringify({ name: found.name, email: found.email, role: normalizedRole }));
      onLogin({ name: found.name, email: found.email, role: normalizedRole });
    } else { setError('Invalid email or password.'); }
    setLoading(false);
  };

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault(); setError('');
    if (!name.trim() || !email.trim() || !password.trim()) { setError('All fields are required.'); return; }
    if (password.length < 6) { setError('Password must be at least 6 characters.'); return; }
    setLoading(true);
    await new Promise(r => setTimeout(r, 700));
    setLoading(false); setSignupDone(true);
    setTimeout(() => {
      const u = { name, email, role };
      saveNewUser({ email, password, name, role });
      localStorage.setItem('ds_user', JSON.stringify(u));
      onLogin(u);
    }, 1000);
  };

  const inputCls = "w-full border border-slate-300 rounded-lg text-sm text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-slate-900/10 focus:border-slate-500 transition-shadow";

  return (
    <div className="min-h-screen bg-white flex">
      {/* ── Form panel ── */}
      <div className="flex-1 flex items-center justify-center px-6 py-12">
        <div className="w-full max-w-sm">
          <h1 className="text-2xl font-bold text-slate-900 mb-1">
            {mode === 'login' ? 'Welcome back' : 'Create account'}
          </h1>
          <p className="text-slate-500 text-sm mb-8">
            {mode === 'login' ? 'Sign in to your workspace.' : 'Get started with DataShield.'}
          </p>

          {/* Tab toggle */}
          <div className="flex border border-slate-200 rounded-lg p-1 mb-6 gap-1">
            {(['login', 'signup'] as const).map(m => (
              <button key={m} onClick={() => { setMode(m); setError(''); setSignupDone(false); }}
                className={`flex-1 py-2 rounded-md text-sm font-semibold transition-all ${
                  mode === m ? 'bg-slate-900 text-white shadow-sm' : 'text-slate-500 hover:text-slate-900'
                }`}>
                {m === 'login' ? 'Sign In' : 'Sign Up'}
              </button>
            ))}
          </div>

          {signupDone ? (
            <div className="text-center py-10 border border-emerald-200 bg-emerald-50 rounded-xl">
              <ShieldCheck className="w-10 h-10 text-emerald-600 mx-auto mb-2" />
              <p className="font-semibold text-slate-900">Account created!</p>
              <p className="text-slate-500 text-sm mt-1">Signing you in…</p>
            </div>
          ) : mode === 'login' ? (
            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">Email address</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input type="email" value={email} onChange={e => setEmail(e.target.value)} required
                    placeholder="you@organisation.com" className={`${inputCls} pl-10 pr-4 py-2.5`} />
                </div>
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">Password</label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input type={showPw ? 'text' : 'password'} value={password} onChange={e => setPassword(e.target.value)} required
                    placeholder="••••••••" className={`${inputCls} pl-10 pr-10 py-2.5`} />
                  <button type="button" onClick={() => setShowPw(v => !v)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600">
                    {showPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>
              {error && <p className="text-sm text-rose-600 bg-rose-50 border border-rose-200 rounded-lg px-3 py-2">{error}</p>}
              <button type="submit" disabled={loading}
                className="w-full bg-slate-900 hover:bg-slate-800 text-white font-semibold py-2.5 rounded-lg text-sm transition-colors flex items-center justify-center gap-2 disabled:opacity-60">
                {loading
                  ? <svg className="animate-spin w-4 h-4" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="3"/><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z"/></svg>
                  : <>Sign In <ArrowRight className="w-4 h-4" /></>}
              </button>

              {/* Demo accounts */}
              <div className="pt-4 border-t border-slate-100">
                <p className="text-xs font-semibold text-slate-400 uppercase tracking-wide mb-3">Demo accounts — click to fill</p>
                <div className="space-y-2">
                  {DEMO_USERS.map(u => (
                    <button key={u.email} type="button"
                      onClick={() => { setEmail(u.email); setPassword(u.password); setError(''); }}
                      className="w-full flex items-center justify-between px-3 py-2.5 rounded-lg border border-slate-200 hover:border-slate-300 hover:bg-slate-50 transition-all text-left">
                      <div>
                        <p className="text-xs font-semibold text-slate-900">{u.name}</p>
                        <p className="text-[11px] text-slate-500">{u.email}</p>
                      </div>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded border ${roleColor(u.role)}`}>{u.role}</span>
                    </button>
                  ))}
                </div>
              </div>
            </form>
          ) : (
            <form onSubmit={handleSignup} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">Full name</label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input type="text" value={name} onChange={e => setName(e.target.value)} required
                    placeholder="Your full name" className={`${inputCls} pl-10 pr-4 py-2.5`} />
                </div>
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">Email address</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input type="email" value={email} onChange={e => setEmail(e.target.value)} required
                    placeholder="you@organisation.com" className={`${inputCls} pl-10 pr-4 py-2.5`} />
                </div>
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">Role</label>
                <select value={role} onChange={e => setRole(e.target.value)}
                  className={`${inputCls} px-3 py-2.5`}>
                  {['Analyst','Reviewer','Admin','Legal','Data Governance'].map(r => <option key={r}>{r}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">Password</label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input type={showPw ? 'text' : 'password'} value={password} onChange={e => setPassword(e.target.value)} required
                    placeholder="Min 6 characters" className={`${inputCls} pl-10 pr-10 py-2.5`} />
                  <button type="button" onClick={() => setShowPw(v => !v)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600">
                    {showPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>
              {error && <p className="text-sm text-rose-600 bg-rose-50 border border-rose-200 rounded-lg px-3 py-2">{error}</p>}
              <button type="submit" disabled={loading}
                className="w-full bg-slate-900 hover:bg-slate-800 text-white font-semibold py-2.5 rounded-lg text-sm transition-colors flex items-center justify-center gap-2 disabled:opacity-60">
                {loading
                  ? <svg className="animate-spin w-4 h-4" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="3"/><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z"/></svg>
                  : <>Create Account <ArrowRight className="w-4 h-4" /></>}
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
