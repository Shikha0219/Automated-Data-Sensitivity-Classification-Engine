import { useEffect, useState } from 'react';
import {
  RefreshCw, AlertTriangle, CheckCircle2, TrendingDown,
  Layers, Activity, ClipboardCheck, Database, PlayCircle,
} from 'lucide-react';
import {
  BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Tooltip, Cell, LineChart, Line, CartesianGrid,
} from 'recharts';
import {
  PageHeader, Card, KpiCard, SectionTitle, Spinner, EmptyState, LabelBadge,
} from '../components/UI';
import { api } from '../lib/api';

const LABEL_COLORS: Record<string, string> = {
  Public: '#10b981', Internal: '#3b82f6', Confidential: '#f59e0b', Restricted: '#ef4444',
};

type Tab = 'overview' | 'drift' | 'audit';

export default function MLOpsPage() {
  const [tab, setTab] = useState<Tab>('overview');
  const [metrics, setMetrics] = useState<any>(null);
  const [registry, setRegistry] = useState<any>(null);

  const [drift, setDrift] = useState<any>(null);
  const [retraining, setRetraining] = useState<any>(null);
  const [audit, setAudit] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const loadAll = async () => {
    setRefreshing(true);
    try {
      const [m, r, d, rt, a] = await Promise.allSettled([
        api.metrics(),
        api.mlopsRegistry(),
        api.mlopsDrift(),
        api.mlopsRetraining(),
        api.mlopsAudit(50),
      ]);
      if (m.status === 'fulfilled') setMetrics(m.value);
      if (r.status === 'fulfilled') setRegistry(r.value);
      if (d.status === 'fulfilled') setDrift(d.value);
      if (rt.status === 'fulfilled') setRetraining(rt.value);
      if (a.status === 'fulfilled') setAudit(a.value);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => { loadAll(); }, []);

  if (loading) {
    return (
      <div>
        <PageHeader title="MLOps Dashboard" subtitle="Drift monitoring and audit log." />
        <Card>
          <div className="flex items-center justify-center py-10">
            <Spinner className="w-7 h-7 text-slate-400" />
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div>
      <PageHeader
        title="MLOps Dashboard"
        subtitle="Drift monitoring and audit log."
        action={
          <button onClick={loadAll} disabled={refreshing} className="btn-secondary text-sm">
            {refreshing ? <Spinner className="w-3.5 h-3.5" /> : <RefreshCw className="w-3.5 h-3.5" />}
            Refresh
          </button>
        }
      />

      {/* Tabs */}
      <div className="flex items-center gap-1 mb-5 bg-slate-100 p-1 rounded-md w-fit">
        <TabBtn active={tab === 'overview'} onClick={() => setTab('overview')}>Overview</TabBtn>
        <TabBtn active={tab === 'drift'} onClick={() => setTab('drift')}>Drift</TabBtn>
        <TabBtn active={tab === 'audit'} onClick={() => setTab('audit')}>Audit log</TabBtn>
      </div>

      {tab === 'overview' && (
        <OverviewTab metrics={metrics} drift={drift} registry={registry} retraining={retraining} />
      )}
      {tab === 'drift' && <DriftTab drift={drift} onRefresh={loadAll} />}
      {tab === 'audit' && <AuditTab audit={audit} />}
    </div>
  );
}

function TabBtn({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      onClick={onClick}
      className={`px-3.5 py-1.5 text-sm font-medium rounded transition-colors ${
        active ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-slate-900'
      }`}
    >
      {children}
    </button>
  );
}

// ─────────────────────────────────────────────────────────────
// Overview tab
// ─────────────────────────────────────────────────────────────
function OverviewTab({ metrics, drift, registry, retraining }: any) {
  if (!metrics) return null;

  const dist = metrics.label_distribution || {};
  const distData = Object.entries(dist).map(([k, v]) => ({ name: k, value: v as number }));
  const overrideRate = metrics.human_override_rate || 0;
  const compliant = metrics.override_rate_compliant;

  const driftStatus =
    drift?.status === 'insufficient_data' ? 'pending' :
    drift?.drift_critical ? 'critical' :
    drift?.drift_detected ? 'warning' : 'ok';

  const championVersion = registry?.champion?.version || '—';
  const pendingOverrides = retraining?.pending_overrides_count ?? 0;

  return (
    <div className="space-y-5 fade-in">
      {/* KPI row */}
      <div className="grid grid-cols-4 gap-4">
        <KpiCard label="Total classified" value={metrics.total_classified.toLocaleString()} />
        <KpiCard
          label="Avg confidence"
          value={`${(metrics.avg_confidence * 100).toFixed(1)}%`}
        />
        <KpiCard
          label="Override rate"
          value={`${overrideRate.toFixed(2)}%`}
          delta={compliant ? 'Within 5% target' : 'KPI breach'}
          deltaTone={compliant ? 'good' : 'bad'}
        />

      </div>

      {/* Compliance row */}
      <div className="grid grid-cols-2 gap-4">
        <StatusTile
          icon={ClipboardCheck}
          title="Compliance"
          status={compliant ? 'ok' : 'bad'}
          label={compliant ? 'Override rate within target' : 'Override rate above 5%'}
          hint="KPI target: <5% of classifications require correction post-deploy."
        />
        <StatusTile
          icon={TrendingDown}
          title="Drift"
          status={driftStatus}
          label={
            driftStatus === 'pending'  ? 'Insufficient data' :
            driftStatus === 'critical' ? 'Critical drift detected' :
            driftStatus === 'warning'  ? 'Mild drift detected' :
                                          'No drift detected'
          }
          hint={drift?.psi_score != null ? `PSI score: ${drift.psi_score}` : 'Run drift check from Drift tab.'}
        />
      </div>

      {/* Label distribution */}
      <Card>
        <SectionTitle>Label distribution</SectionTitle>
        {distData.length > 0 ? (
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={distData} margin={{ top: 8, right: 0, left: -16, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                <XAxis dataKey="name" tick={{ fontSize: 12, fill: '#475569' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 12, fill: '#475569' }} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={{ fontSize: 12, borderRadius: 6, border: '1px solid #e2e8f0', boxShadow: '0 2px 8px rgba(0,0,0,0.04)' }} />
                <Bar dataKey="value" radius={[4, 4, 0, 0]}>
                  {distData.map(d => <Cell key={d.name} fill={LABEL_COLORS[d.name] || '#94a3b8'} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        ) : (
          <div className="text-sm text-slate-500 py-8 text-center">No classifications yet.</div>
        )}
      </Card>
    </div>
  );
}

function StatusTile({
  icon: Icon, title, status, label, hint,
}: {
  icon: React.ComponentType<{ className?: string; strokeWidth?: number }>;
  title: string;
  status: 'ok' | 'warning' | 'bad' | 'pending' | 'critical';
  label: string;
  hint?: string;
}) {
  const dotCls =
    status === 'ok'                          ? 'dot-good' :
    status === 'warning'                     ? 'dot-warn' :
    status === 'bad' || status === 'critical' ? 'dot-bad' :
                                                'dot-neutral';
  return (
    <div className="card p-5">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Icon className="w-4 h-4 text-slate-500" strokeWidth={1.8} />
          <span className="kpi-label">{title}</span>
        </div>
        <span className={`dot ${dotCls}`} />
      </div>
      <div className="mt-3 text-sm font-medium text-slate-800">{label}</div>
      {hint && <div className="text-xs text-slate-500 mt-1.5">{hint}</div>}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Registry tab
// ─────────────────────────────────────────────────────────────
function RegistryTab({ registry }: any) {
  if (!registry || registry.error) {
    return (
      <Card>
        <EmptyState
          icon={Layers}
          title="No registered models"
          hint="Run `python mlops.py` once to bootstrap the registry with the bundled artifact."
        />
      </Card>
    );
  }

  return (
    <div className="space-y-4 fade-in">
      <ModelTile label="Champion" entry={registry.champion} tone="good" />
      <ModelTile label="Challenger" entry={registry.challenger} tone="neutral" />

      {registry.history?.length > 0 && (
        <Card>
          <SectionTitle>History</SectionTitle>
          <div className="border border-slate-200 rounded overflow-hidden">
            <table className="w-full text-sm">
              <thead className="table-head">
                <tr>
                  <th className="px-3 py-2 text-left">Version</th>
                  <th className="px-3 py-2 text-left">Status</th>
                  <th className="px-3 py-2 text-left">F1-macro</th>
                  <th className="px-3 py-2 text-left">Registered</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {registry.history.map((h: any, i: number) => (
                  <tr key={i} className="hover:bg-slate-50/60">
                    <td className="px-3 py-2 font-mono text-xs">{h.version}</td>
                    <td className="px-3 py-2"><span className="chip">{h.status}</span></td>
                    <td className="px-3 py-2 tabular-nums">{h.metrics?.f1_macro?.toFixed(3) ?? '—'}</td>
                    <td className="px-3 py-2 text-xs text-slate-500">{h.registered_at?.slice(0, 19).replace('T', ' ')}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      )}
    </div>
  );
}

function ModelTile({ label, entry, tone }: { label: string; entry: any; tone: 'good' | 'neutral' }) {
  return (
    <Card>
      <div className="flex items-start justify-between">
        <div>
          <div className="kpi-label">{label}</div>
          {entry ? (
            <>
              <div className="mt-1 text-lg font-semibold text-slate-900 font-mono">{entry.version}</div>
              <div className="text-xs text-slate-500 mt-1">
                Registered {entry.registered_at?.slice(0, 19).replace('T', ' ')}
              </div>
            </>
          ) : (
            <div className="mt-1 text-sm text-slate-500">None registered.</div>
          )}
        </div>
        {entry && (
          <span className={`pill ${tone === 'good' ? 'label-public' : 'label-internal'}`}>
            {entry.status || label.toLowerCase()}
          </span>
        )}
      </div>

      {entry?.metrics && (
        <div className="mt-4 grid grid-cols-3 gap-4">
          {Object.entries(entry.metrics).map(([k, v]) => (
            <div key={k} className="surface p-3">
              <div className="text-[11px] tracking-wide uppercase text-slate-500">{k.replace(/_/g, ' ')}</div>
              <div className="text-lg font-semibold text-slate-900 tabular-nums mt-1">
                {typeof v === 'number' ? (v as number).toFixed(3) : String(v)}
              </div>
            </div>
          ))}
        </div>
      )}
    </Card>
  );
}

// ─────────────────────────────────────────────────────────────
// Drift tab
// ─────────────────────────────────────────────────────────────
function DriftTab({ drift, onRefresh }: { drift: any; onRefresh: () => void }) {
  if (!drift) return <Card><EmptyState icon={Activity} title="Drift data unavailable" /></Card>;

  if (drift.status === 'insufficient_data') {
    return (
      <Card>
        <SectionTitle>Drift monitoring</SectionTitle>
        <div className="flex items-start gap-3 bg-amber-50 border border-amber-200 rounded p-3 text-sm">
          <AlertTriangle className="w-4 h-4 text-amber-600 mt-0.5 flex-shrink-0" />
          <div>
            <div className="font-medium text-amber-900">Not enough data yet</div>
            <div className="text-amber-800 mt-1">{drift.message}</div>
            <div className="text-amber-700 mt-2 text-xs">
              Classify a few more documents from the Classify page, then come back here.
            </div>
          </div>
        </div>
        <div className="mt-3">
          <button onClick={onRefresh} className="btn-secondary text-sm">
            <RefreshCw className="w-3.5 h-3.5" /> Recompute
          </button>
        </div>
      </Card>
    );
  }

  const recommendation =
    drift.drift_critical ? { tone: 'bad', text: drift.recommendation, icon: AlertTriangle } :
    drift.drift_detected ? { tone: 'warn', text: drift.recommendation, icon: AlertTriangle } :
                            { tone: 'ok', text: drift.recommendation, icon: CheckCircle2 };

  // Build comparison data for chart
  const refDist = drift.label_distribution?.reference || {};
  const curDist = drift.label_distribution?.current || {};
  const labels = Array.from(new Set([...Object.keys(refDist), ...Object.keys(curDist)]));
  const compareData = labels.map(l => ({
    name: l,
    reference: refDist[l] || 0,
    current: curDist[l] || 0,
  }));

  return (
    <div className="space-y-4 fade-in">
      {/* PSI summary */}
      <div className="grid grid-cols-3 gap-4">
        <KpiCard
          label="PSI score"
          value={drift.psi_score?.toFixed(4)}
          delta={
            drift.drift_critical ? '>0.25 critical' :
            drift.drift_detected ? '>0.20 mild' : '<0.20 stable'
          }
          deltaTone={drift.drift_critical ? 'bad' : drift.drift_detected ? 'neutral' : 'good'}
        />
        <KpiCard
          label="Confidence drop"
          value={`${(drift.confidence_drop * 100).toFixed(2)}%`}
          delta={`Ref ${(drift.avg_confidence?.reference * 100 || 0).toFixed(1)}% → Cur ${(drift.avg_confidence?.current * 100 || 0).toFixed(1)}%`}
          deltaTone="neutral"
        />
        <KpiCard
          label="SLA status"
          value={drift.alert_sla_breach ? 'Breach' : 'OK'}
          delta={drift.alert_sla_breach ? 'Retrain within 48h' : 'No action required'}
          deltaTone={drift.alert_sla_breach ? 'bad' : 'good'}
        />
      </div>

      {/* Recommendation */}
      <Card className={
        recommendation.tone === 'bad'  ? 'border-rose-200 bg-rose-50/60' :
        recommendation.tone === 'warn' ? 'border-amber-200 bg-amber-50/60' :
                                          'border-emerald-200 bg-emerald-50/60'
      }>
        <div className="flex items-start gap-3">
          <recommendation.icon
            className={`w-5 h-5 mt-0.5 flex-shrink-0 ${
              recommendation.tone === 'bad' ? 'text-rose-600' :
              recommendation.tone === 'warn' ? 'text-amber-600' :
              'text-emerald-600'
            }`}
            strokeWidth={1.8}
          />
          <div>
            <div className="font-medium text-slate-900">Recommendation</div>
            <div className="text-sm text-slate-700 mt-0.5">{recommendation.text}</div>
            <div className="text-xs text-slate-500 mt-2">
              Computed at {drift.computed_at?.slice(0, 19).replace('T', ' ')} · reference window: {drift.reference_window} · current window: {drift.current_window}
            </div>
          </div>
        </div>
      </Card>

      {/* Reference vs Current */}
      <Card>
        <SectionTitle hint="Distribution shift between the reference period (older entries) and the current window (most recent).">
          Reference vs current label distribution
        </SectionTitle>
        {compareData.length > 0 ? (
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={compareData} margin={{ top: 8, right: 0, left: -16, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                <XAxis dataKey="name" tick={{ fontSize: 12, fill: '#475569' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 12, fill: '#475569' }} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={{ fontSize: 12, borderRadius: 6, border: '1px solid #e2e8f0' }} />
                <Bar dataKey="reference" fill="#94a3b8" radius={[3, 3, 0, 0]} />
                <Bar dataKey="current"   fill="#0f172a" radius={[3, 3, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        ) : (
          <div className="text-sm text-slate-500 py-6 text-center">No data.</div>
        )}
      </Card>

    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Retraining tab
// ─────────────────────────────────────────────────────────────
function RetrainingTab({ retraining, onAction }: { retraining: any; onAction: () => void }) {
  const [exporting, setExporting] = useState(false);
  const [retraining_, setRetraining_] = useState(false);
  const [exportRes, setExportRes] = useState<any>(null);
  const [retrainRes, setRetrainRes] = useState<any>(null);

  if (!retraining) return null;

  const doExport = async () => {
    setExporting(true);
    try { setExportRes(await api.exportTrainingBatch()); }
    finally { setExporting(false); onAction(); }
  };

  const doRetrain = async () => {
    setRetraining_(true);
    try { setRetrainRes(await api.mlopsRetrain()); }
    finally { setRetraining_(false); onAction(); }
  };

  const pending = retraining.pending_overrides_count ?? 0;
  const trigger = retraining.drift_trigger || {};

  return (
    <div className="space-y-4 fade-in">
      <div className="grid grid-cols-2 gap-4">
        <KpiCard
          label="Pending overrides"
          value={pending}
          delta={pending === 0 ? 'No corrections accumulated' : 'Available for retraining'}
          deltaTone={pending === 0 ? 'good' : 'neutral'}
        />
        <KpiCard
          label="Drift trigger"
          value={trigger.trigger ? 'YES' : 'No'}
          delta={trigger.reason || '—'}
          deltaTone={trigger.trigger ? 'bad' : 'good'}
        />
      </div>

      <Card>
        <SectionTitle hint="Lightweight retraining workflow: export corrections to a CSV, then invoke the training script (or use the on-page button for a dry run).">
          Retraining workflow
        </SectionTitle>

        <ol className="space-y-3 text-sm text-slate-700">
          <li className="flex gap-3">
            <span className="flex-shrink-0 w-6 h-6 bg-slate-100 text-slate-700 rounded-full flex items-center justify-center text-xs font-semibold">1</span>
            <div className="flex-1">
              <div className="font-medium">Export corrections batch</div>
              <p className="text-xs text-slate-500 mt-0.5">
                Bundle all human overrides into a CSV ready for the next training run.
              </p>
              <div className="mt-2 flex items-center gap-2">
                <button onClick={doExport} disabled={exporting || pending === 0} className="btn-secondary text-xs">
                  {exporting ? <Spinner className="w-3.5 h-3.5" /> : <Database className="w-3.5 h-3.5" />}
                  Export batch
                </button>
                {exportRes && (
                  <span className="text-xs text-slate-600">
                    {exportRes.exported ? (
                      <>Exported to <code className="font-mono">{exportRes.path}</code></>
                    ) : exportRes.reason}
                  </span>
                )}
              </div>
            </div>
          </li>

          <li className="flex gap-3">
            <span className="flex-shrink-0 w-6 h-6 bg-slate-100 text-slate-700 rounded-full flex items-center justify-center text-xs font-semibold">2</span>
            <div className="flex-1">
              <div className="font-medium">Queue retraining request</div>
              <p className="text-xs text-slate-500 mt-0.5">
                Records a retraining request in <code>logs/retraining_requests.jsonl</code> and prints
                the exact CLI command to run.
              </p>
              <div className="mt-2 flex items-center gap-2">
                <button onClick={doRetrain} disabled={retraining_} className="btn-primary text-xs">
                  {retraining_ ? <Spinner className="w-3.5 h-3.5" /> : <PlayCircle className="w-3.5 h-3.5" />}
                  Queue retraining
                </button>
                {retrainRes && (
                  <span className="text-xs text-slate-600">{retrainRes.reason}</span>
                )}
              </div>
              {retrainRes?.next_step && (
                <div className="mt-2 text-xs bg-slate-900 text-slate-100 font-mono p-2 rounded">
                  $ {retrainRes.next_step}
                </div>
              )}
            </div>
          </li>

          <li className="flex gap-3">
            <span className="flex-shrink-0 w-6 h-6 bg-slate-100 text-slate-700 rounded-full flex items-center justify-center text-xs font-semibold">3</span>
            <div className="flex-1">
              <div className="font-medium">Monthly schedule</div>
              <p className="text-xs text-slate-500 mt-0.5">
                Retraining is also triggered automatically once a month or when drift exceeds the configured PSI threshold.
                See <code>mlops.py</code> · <code>check_retraining_trigger()</code>.
              </p>
            </div>
          </li>
        </ol>
      </Card>
    </div>
  );
}


// ─────────────────────────────────────────────────────────────
// Reason cell — builds a human-readable reason from audit entry
// ─────────────────────────────────────────────────────────────
function ReasonCell({ entry }: { entry: any }) {
  const [expanded, setExpanded] = useState(false);

  const buildReason = (): string => {
    const parts: string[] = [];

    // PII override
    if (entry.pii_detected && (typeof entry.pii_detected === 'boolean' ? entry.pii_detected : Object.keys(entry.pii_detected || {}).length > 0)) {
      parts.push('PII detected — label forced to Restricted');
    }

    // Evidence tokens
    const ev = entry.evidence || [];
    if (ev.length > 0) {
      const topTokens = ev.slice(0, 3).map((e: any) => `"${e.token}"`).join(', ');
      parts.push(`Top evidence: ${topTokens}`);
    }

    // Confidence level
    if (entry.confidence != null) {
      const conf = entry.confidence * 100;
      if (conf >= 90) parts.push('High confidence (≥90%)');
      else if (conf >= 70) parts.push(`Normal confidence (${conf.toFixed(0)}%)`);
      else parts.push(`Low confidence (${conf.toFixed(0)}%) — flagged for review`);
    }

    // Human override
    if (entry.human_override) {
      parts.push(`Human override: ${entry.human_override.original_label} → ${entry.human_override.corrected_label}`);
    }

    // Policy action
    if (entry.policy_action) {
      parts.push(`Policy: ${entry.policy_action}`);
    }

    return parts.length > 0 ? parts.join(' · ') : 'Classified by ML ensemble';
  };

  const reason = buildReason();
  const isLong = reason.length > 60;
  const display = !expanded && isLong ? reason.slice(0, 60) + '…' : reason;

  return (
    <div>
      <span className="text-slate-600 leading-relaxed">{display}</span>
      {isLong && (
        <button
          onClick={() => setExpanded(v => !v)}
          className="ml-1 text-blue-500 hover:text-blue-700 font-medium text-[11px]"
        >
          {expanded ? 'less' : 'more'}
        </button>
      )}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Audit tab
// ─────────────────────────────────────────────────────────────
function AuditTab({ audit }: { audit: any }) {
  if (!audit || !audit.entries?.length) {
    return <Card><EmptyState icon={ClipboardCheck} title="Audit log is empty" hint="Classify a document to populate it." /></Card>;
  }

  return (
    <Card padded={false}>
      <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between bg-gradient-to-r from-slate-50 to-white rounded-t-lg">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-slate-900 flex items-center justify-center">
            <ClipboardCheck className="w-4 h-4 text-white" strokeWidth={1.8} />
          </div>
          <div>
            <SectionTitle>Recent audit entries</SectionTitle>
            <p className="text-[11px] text-slate-400 -mt-2">Immutable classification record · PII masked</p>
          </div>
        </div>
        <span className="text-xs font-semibold text-slate-500 bg-slate-100 border border-slate-200 px-3 py-1 rounded-full">
          {audit.returned} / {audit.total} entries
        </span>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="table-head">
            <tr>
              <th className="px-4 py-2 text-left">Timestamp</th>
              <th className="px-4 py-2 text-left">Doc ID</th>
              <th className="px-4 py-2 text-left">Label</th>
              <th className="px-4 py-2 text-left">Confidence</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {audit.entries.map((e: any, i: number) => (
              <tr key={i} className="hover:bg-slate-50/60">
                <td className="px-4 py-2 text-xs text-slate-600 font-mono">{e.timestamp_utc?.slice(0, 19).replace('T', ' ')}</td>
                <td className="px-4 py-2 text-xs font-mono text-slate-700">{e.doc_id?.slice(0, 16)}</td>
                <td className="px-4 py-2"><LabelBadge label={e.label} /></td>
                <td className="px-4 py-2 tabular-nums text-xs">{e.confidence != null ? `${(e.confidence * 100).toFixed(1)}%` : '—'}</td>
                <td className="px-4 py-2 text-xs text-slate-600 max-w-xs">
                  <ReasonCell entry={e} />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Card>
  );
}
