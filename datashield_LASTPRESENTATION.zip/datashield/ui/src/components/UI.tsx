import { labelClass, actionClass } from '../lib/api';

export function PageHeader({
  title, subtitle, action,
}: {
  title: string;
  subtitle?: string;
  action?: React.ReactNode;
}) {
  return (
    <div className="mb-6 flex items-end justify-between gap-4 pb-4 border-b border-slate-200">
      <div>
        <h1 className="text-[22px] font-semibold tracking-tight text-slate-900">{title}</h1>
        {subtitle && <p className="text-sm text-slate-500 mt-1 max-w-2xl">{subtitle}</p>}
      </div>
      {action}
    </div>
  );
}

export function Card({
  children, className = '', padded = true,
}: {
  children: React.ReactNode;
  className?: string;
  padded?: boolean;
}) {
  return (
    <div className={`card ${padded ? 'p-5' : ''} ${className}`}>
      {children}
    </div>
  );
}

export function SectionTitle({
  children, hint,
}: {
  children: React.ReactNode;
  hint?: string;
}) {
  return (
    <div className="mb-3">
      <h2 className="text-[13px] font-semibold tracking-wide text-slate-700 uppercase">{children}</h2>
      {hint && <p className="text-xs text-slate-500 mt-0.5">{hint}</p>}
    </div>
  );
}

export function LabelBadge({ label }: { label: string | undefined }) {
  return <span className={`pill ${labelClass(label)}`}>{label || '—'}</span>;
}

export function ActionBadge({ action }: { action: string | undefined }) {
  return <span className={`pill ${actionClass(action)}`}>{action || '—'}</span>;
}

export function KpiCard({
  label, value, delta, deltaTone,
}: {
  label: string;
  value: React.ReactNode;
  delta?: string;
  deltaTone?: 'good' | 'bad' | 'neutral';
}) {
  const tone =
    deltaTone === 'good'    ? 'text-emerald-600' :
    deltaTone === 'bad'     ? 'text-rose-600' :
                              'text-slate-500';
  return (
    <div className="card p-5">
      <div className="kpi-label">{label}</div>
      <div className="kpi-value">{value}</div>
      {delta && <div className={`kpi-delta ${tone}`}>{delta}</div>}
    </div>
  );
}

export function EmptyState({
  icon: Icon, title, hint, action,
}: {
  icon: React.ComponentType<{ className?: string; strokeWidth?: number }>;
  title: string;
  hint?: string;
  action?: React.ReactNode;
}) {
  return (
    <div className="text-center py-14 text-slate-500">
      <Icon className="w-10 h-10 mx-auto text-slate-300 mb-3" strokeWidth={1.5} />
      <div className="font-medium text-slate-700">{title}</div>
      {hint && <div className="text-sm mt-1 text-slate-500">{hint}</div>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

export function Spinner({ className = 'w-4 h-4' }: { className?: string }) {
  return (
    <svg className={`animate-spin ${className}`} fill="none" viewBox="0 0 24 24">
      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="3" />
      <path className="opacity-75" fill="currentColor"
            d="M4 12a8 8 0 018-8V0C5.4 0 0 5.4 0 12h4zm2 5.3A8 8 0 014 12H0c0 3 1.1 5.8 3 7.9l3-2.6z" />
    </svg>
  );
}

export function ProgressBar({
  value, max, tone = 'brand',
}: {
  value: number;
  max: number;
  tone?: 'brand' | 'success' | 'danger';
}) {
  const pct = Math.min(100, Math.max(0, (value / Math.max(max, 1)) * 100));
  const cls =
    tone === 'success' ? 'bg-emerald-500' :
    tone === 'danger'  ? 'bg-rose-500' :
                         'bg-slate-900';
  return (
    <div className="w-full bg-slate-100 rounded-full h-1.5 overflow-hidden">
      <div
        className={`${cls} h-1.5 rounded-full transition-all duration-300`}
        style={{ width: `${pct}%` }}
      />
    </div>
  );
}

export function StatusDot({
  status,
}: {
  status: 'queued' | 'running' | 'done' | 'failed' | string;
}) {
  const cls =
    status === 'done'    ? 'dot-good' :
    status === 'running' ? 'dot-warn' :
    status === 'failed'  ? 'dot-bad' :
                           'dot-neutral';
  const label =
    status === 'done'    ? 'Done' :
    status === 'running' ? 'Running' :
    status === 'failed'  ? 'Failed' :
                           'Queued';
  return (
    <span className="inline-flex items-center gap-1.5 text-xs text-slate-700">
      <span className={`dot ${cls}`} />
      {label}
    </span>
  );
}
