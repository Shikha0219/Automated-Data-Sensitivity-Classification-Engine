import { useEffect, useState, useCallback, useRef } from 'react';
import { Routes, Route, NavLink, Navigate, useNavigate, useLocation } from 'react-router-dom';
import {
  ShieldCheck, FileScan, ClipboardList, GitMerge, Activity,
  LogOut, ChevronDown, User, LayoutDashboard, Moon, Sun,
} from 'lucide-react';
import ClassifyPage from './pages/ClassifyPage';
import HistoryPage from './pages/HistoryPage';
import ApprovalsPage from './pages/ApprovalsPage';
import MLOpsPage from './pages/MLOpsPage';
import DashboardPage from './pages/DashboardPage';
import LoginPage from './pages/LoginPage';
import { api } from './lib/api';

interface DSUser { name: string; email: string; role: string; }

// ── Role permissions ────────────────────────────────────────────────────
const ROLE_PERMISSIONS: Record<string, string[]> = {
  Admin:            ['dashboard','classify','history','approvals','mlops'],
  Reviewer:         ['dashboard','approvals','history'],
  Analyst:          ['dashboard','classify','history'],
  Legal:            ['dashboard','approvals','history'],
  'Data Governance':['dashboard','approvals','history'],
};

const ALL_NAV = [
  { to: '/dashboard',  label: 'Dashboard',  icon: LayoutDashboard, perm: 'dashboard'  },
  { to: '/classify',   label: 'Classify',   icon: FileScan,        perm: 'classify'   },
  { to: '/history',    label: 'History',    icon: ClipboardList,   perm: 'history'    },
  { to: '/approvals',  label: 'Approvals',  icon: GitMerge,        perm: 'approvals'  },
  { to: '/mlops',      label: 'MLOps',      icon: Activity,        perm: 'mlops'      },
];

const SESSION_TIMEOUT_MS = 15 * 60 * 1000; // 15 minutes inactivity

// ── Activity logger ─────────────────────────────────────────────────────
export interface ActivityEntry {
  id: string; ts: string; user: string; role: string;
  action: string; detail: string; page: string;
}
const ACTIVITY_KEY = 'ds_activity_log';
export function logActivity(user: DSUser, action: string, detail: string, page: string) {
  const existing: ActivityEntry[] = JSON.parse(localStorage.getItem(ACTIVITY_KEY) || '[]');
  const entry: ActivityEntry = {
    id: Math.random().toString(36).slice(2),
    ts: new Date().toISOString(),
    user: user.name, role: user.role, action, detail, page,
  };
  existing.unshift(entry);
  localStorage.setItem(ACTIVITY_KEY, JSON.stringify(existing.slice(0, 200)));
}

export default function App() {
  const [apiOnline, setApiOnline]     = useState<boolean | null>(null);
  const [darkMode, setDarkMode]       = useState(() => localStorage.getItem('ds_dark') === '1');
  const [user, setUser]               = useState<DSUser | null>(() => {
    try { return JSON.parse(localStorage.getItem('ds_user') || 'null'); } catch { return null; }
  });
  const [showUserMenu, setShowUserMenu] = useState(false);
  const timeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const navigate   = useNavigate();
  const location   = useLocation();

  // Dark mode
  useEffect(() => {
    document.documentElement.classList.toggle('dark', darkMode);
    localStorage.setItem('ds_dark', darkMode ? '1' : '0');
  }, [darkMode]);

  // API health
  useEffect(() => {
    const check = async () => {
      try { await api.health(); setApiOnline(true); } catch { setApiOnline(false); }
    };
    check();
    const id = setInterval(check, 5000);
    return () => clearInterval(id);
  }, []);

  // Session timeout
  const resetTimer = useCallback(() => {
    if (timeoutRef.current) clearTimeout(timeoutRef.current);
    timeoutRef.current = setTimeout(() => {
      if (user) {
        logActivity(user, 'SESSION_TIMEOUT', 'Auto-logout due to inactivity', location.pathname);
        handleLogout();
      }
    }, SESSION_TIMEOUT_MS);
  }, [user, location.pathname]);

  useEffect(() => {
    if (!user) return;
    const events = ['mousedown','keydown','scroll','touchstart'];
    events.forEach(e => window.addEventListener(e, resetTimer, { passive: true }));
    resetTimer();
    return () => {
      events.forEach(e => window.removeEventListener(e, resetTimer));
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
    };
  }, [user, resetTimer]);

  // Log page navigation
  useEffect(() => {
    if (user) logActivity(user, 'PAGE_VIEW', `Visited ${location.pathname}`, location.pathname);
  }, [location.pathname]);

  const handleLogin = (u: DSUser) => {
    setUser(u);
    logActivity(u, 'LOGIN', 'User signed in', '/');
  };

  const handleLogout = () => {
    if (user) logActivity(user, 'LOGOUT', 'User signed out', location.pathname);
    localStorage.removeItem('ds_user');
    setUser(null);
    setShowUserMenu(false);
    navigate('/');
  };

  if (!user) return <LoginPage onLogin={handleLogin} />;

  const normalizedRole = Object.keys(ROLE_PERMISSIONS).find(
    k => k.toLowerCase() === user.role?.trim().toLowerCase()
  ) ?? user.role;
  const perms  = ROLE_PERMISSIONS[normalizedRole] || ['dashboard'];
  const navItems = ALL_NAV.filter(n => perms.includes(n.perm));

  const roleColor =
    user.role === 'Admin'            ? 'bg-violet-100 text-violet-700 border-violet-200' :
    user.role === 'Reviewer'         ? 'bg-amber-100 text-amber-700 border-amber-200'   :
    user.role === 'Legal'            ? 'bg-rose-100 text-rose-700 border-rose-200'       :
    user.role === 'Data Governance'  ? 'bg-teal-100 text-teal-700 border-teal-200'       :
    'bg-blue-100 text-blue-700 border-blue-200';

  return (
    <div className={`flex min-h-screen ${darkMode ? 'dark bg-gray-950' : 'bg-slate-50'}`}>
      {/* Sidebar */}
      <aside className={`w-60 flex-shrink-0 flex flex-col border-r ${darkMode ? 'bg-gray-900 border-gray-800' : 'bg-white border-slate-200'}`}>
        {/* Brand */}
        <div className={`px-5 py-5 border-b ${darkMode ? 'border-gray-800' : 'border-slate-200'}`}>
          <div className="flex items-center gap-2.5">
            <div className={`w-8 h-8 rounded-md flex items-center justify-center ${darkMode ? 'bg-white' : 'bg-slate-900'}`}>
              <ShieldCheck className={`w-4 h-4 ${darkMode ? 'text-slate-900' : 'text-white'}`} strokeWidth={2} />
            </div>
            <div>
              <div className={`text-[15px] font-semibold tracking-tight leading-none ${darkMode ? 'text-white' : 'text-slate-900'}`}>DataShield</div>
              <div className="text-[11px] text-slate-500 mt-0.5">Sensitivity Engine</div>
            </div>
          </div>
        </div>

        {/* Nav */}
        <nav className="flex-1 px-2.5 py-4 space-y-0.5">
          {navItems.map(item => (
            <NavLink key={item.to} to={item.to}
              className={({ isActive }) =>
                `flex items-center gap-2.5 px-3 py-2 rounded-md text-sm transition-colors ${
                  isActive
                    ? darkMode ? 'bg-gray-700 text-white font-medium' : 'bg-slate-100 text-slate-900 font-medium'
                    : darkMode ? 'text-gray-400 hover:bg-gray-800 hover:text-white' : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                }`
              }
            >
              <item.icon className="w-4 h-4 flex-shrink-0" />
              <span>{item.label}</span>
            </NavLink>
          ))}
        </nav>

        {/* Dark mode + user */}
        <div className={`px-3 pt-3 border-t ${darkMode ? 'border-gray-800' : 'border-slate-200'}`}>
          <button onClick={() => setDarkMode(v => !v)}
            className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-md text-sm mb-2 transition-colors ${darkMode ? 'text-gray-400 hover:bg-gray-800 hover:text-white' : 'text-slate-500 hover:bg-slate-50 hover:text-slate-900'}`}>
            {darkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            {darkMode ? 'Light mode' : 'Dark mode'}
          </button>

          <div className="relative">
            <button onClick={() => setShowUserMenu(v => !v)}
              className={`w-full flex items-center gap-2.5 px-2 py-2 rounded-md transition-colors ${darkMode ? 'hover:bg-gray-800' : 'hover:bg-slate-50'}`}>
              <div className="w-7 h-7 rounded-full bg-slate-900 dark:bg-white flex items-center justify-center flex-shrink-0">
                <User className="w-3.5 h-3.5 text-white dark:text-slate-900" />
              </div>
              <div className="flex-1 text-left min-w-0">
                <div className={`text-xs font-semibold truncate ${darkMode ? 'text-white' : 'text-slate-900'}`}>{user.name}</div>
                <div className="text-[10px] text-slate-500 truncate">{user.email}</div>
              </div>
              <ChevronDown className={`w-3.5 h-3.5 text-slate-400 transition-transform ${showUserMenu ? 'rotate-180' : ''}`} />
            </button>

            {showUserMenu && (
              <div className={`absolute bottom-full left-0 right-0 mb-1 border rounded-lg shadow-lg py-2 z-50 ${darkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-slate-200'}`}>
                <div className={`px-3 pb-2 mb-1 border-b ${darkMode ? 'border-gray-700' : 'border-slate-100'}`}>
                  <div className={`text-xs font-semibold ${darkMode ? 'text-white' : 'text-slate-700'}`}>{user.name}</div>
                  <div className="text-[11px] text-slate-500">{user.email}</div>
                  <span className={`inline-flex items-center mt-1.5 text-[10px] font-bold px-2 py-0.5 rounded border ${roleColor}`}>{user.role}</span>
                </div>
                <button onClick={handleLogout}
                  className={`w-full flex items-center gap-2 px-3 py-1.5 text-sm text-rose-600 transition-colors ${darkMode ? 'hover:bg-gray-700' : 'hover:bg-rose-50'}`}>
                  <LogOut className="w-3.5 h-3.5" /> Sign out
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Status */}
        <div className={`px-4 py-3 border-t ${darkMode ? 'border-gray-800' : 'border-slate-200'}`}>
          <div className="flex items-center gap-2 text-xs text-slate-500">
            <span className={`dot ${apiOnline === true ? 'dot-good' : apiOnline === false ? 'dot-bad' : 'dot-neutral'}`} />
            API {apiOnline === true ? 'connected' : apiOnline === false ? 'offline' : 'checking'}
          </div>
          <div className="text-[10px] text-slate-400 mt-1.5">v3.1.0 · 15 min timeout</div>
        </div>
      </aside>

      {/* Main */}
      <main className={`flex-1 overflow-x-auto ${darkMode ? 'bg-gray-950 text-white' : ''}`}>
        {apiOnline === false && (
          <div className="bg-amber-50 border-b border-amber-200 text-amber-900 px-6 py-2.5 text-sm flex items-center gap-2">
            <span className="dot dot-warn" />
            Backend offline — start with <code className="px-1.5 py-0.5 bg-amber-100 rounded text-[12px] font-mono">python run.py</code>
          </div>
        )}
        <div className="px-8 py-6 max-w-screen-2xl">
          <Routes>
            <Route path="/"           element={<Navigate to="/dashboard" replace />} />
            <Route path="/dashboard"  element={perms.includes('dashboard')  ? <DashboardPage user={user} darkMode={darkMode} /> : <Navigate to="/" />} />
            <Route path="/classify"   element={perms.includes('classify')   ? <ClassifyPage onResult={() => {}} /> : <Navigate to="/" />} />
            <Route path="/history"    element={perms.includes('history')    ? <HistoryPage /> : <Navigate to="/" />} />
            <Route path="/approvals"  element={perms.includes('approvals')  ? <ApprovalsPage /> : <Navigate to="/" />} />
            <Route path="/mlops"      element={perms.includes('mlops')      ? <MLOpsPage /> : <Navigate to="/" />} />
            <Route path="/metrics"    element={<Navigate to="/mlops" replace />} />
          </Routes>
        </div>
      </main>
    </div>
  );
}
