// Centralised API client. The Vite dev server proxies /api/* to http://127.0.0.1:8000.

const API_BASE = '/api';

// ─────────────────────────────────────────────────────────────
// Types
// ─────────────────────────────────────────────────────────────

export interface ClassifyResponse {
  doc_id: string;
  label: string;
  confidence: number;
  class_probabilities: Record<string, number>;
  evidence: Array<{ token: string; weight: number; source: string }>;
  policy_action: string;
  policy_trace: any;
  model_contributions: Record<string, any>;
  language: { detected: string; routed_to: string };
  audit: any;
  preprocessing: any;
  features: any;
  latency_ms: { preprocessing: number; features: number; classification: number; total: number };
  timestamp_utc: string;
  source_file?: string;
  extracted_text_preview?: string;
}

export interface MetricsResponse {
  total_classified: number;
  total_overrides: number;
  total_confirmations?: number;
  human_override_rate: number;
  override_rate_compliant: boolean;
  label_distribution: Record<string, number>;
  avg_confidence: number;
  target_override_rate: string;
}

export interface HistoryEntry {
  doc_id: string;
  label: string;
  confidence: number;
  timestamp_utc: string;
  policy_trace?: any;
  input_snippet_masked?: string;
  evidence_count?: number;
  human_override?: any;
  class_probabilities?: Record<string, number>;
}

export interface BatchFileStatus {
  source_file: string;
  status: 'queued' | 'running' | 'done' | 'failed';
  label?: string;
  confidence?: number;
  policy_action?: string;
  error?: string;
}

export interface BatchJobStatus {
  job_id: string;
  status: 'queued' | 'running' | 'completed' | 'failed';
  submitted_at: string;
  started_at?: string;
  completed_at?: string;
  progress: { completed: number; total: number; failed: number };
  expanded_from_zip?: number;
  files: BatchFileStatus[];
  results: Array<{
    doc_id: string;
    source_file?: string;
    label?: string;
    confidence?: number;
    policy_action?: string;
    error?: string;
  }>;
}

// ─────────────────────────────────────────────────────────────
// Low-level fetch helpers
// ─────────────────────────────────────────────────────────────

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(API_BASE + path, {
    ...init,
    headers: { 'Content-Type': 'application/json', ...(init?.headers || {}) },
  });
  if (!res.ok) {
    const body = await res.text();
    throw new Error(`API ${path} → HTTP ${res.status}: ${body}`);
  }
  return res.json();
}

async function requestFormData<T>(path: string, formData: FormData): Promise<T> {
  const res = await fetch(API_BASE + path, { method: 'POST', body: formData });
  if (!res.ok) {
    const body = await res.text();
    throw new Error(`API ${path} → HTTP ${res.status}: ${body}`);
  }
  return res.json();
}

// ─────────────────────────────────────────────────────────────
// API surface
// ─────────────────────────────────────────────────────────────

export const api = {
  health: () =>
    request<{ status: string; pipeline_loaded: boolean; timestamp_utc: string }>('/health'),

  // Classification
  classifyText: (text: string, opts: { doc_id?: string; source_system?: string; department?: string }) =>
    request<ClassifyResponse>('/classify', {
      method: 'POST',
      body: JSON.stringify({ text, ...opts, file_type: 'txt' }),
    }),

  classifyFile: (file: File, opts: { doc_id?: string; source_system?: string; department?: string }) => {
    const fd = new FormData();
    fd.append('file', file);
    if (opts.doc_id) fd.append('doc_id', opts.doc_id);
    if (opts.source_system) fd.append('source_system', opts.source_system);
    if (opts.department) fd.append('department', opts.department);
    return requestFormData<ClassifyResponse>('/classify/file', fd);
  },

  // Submits any mix of: regular files, files-from-folders, ZIPs.
  // The server auto-expands ZIPs and treats folder-uploaded files
  // (which carry a webkitRelativePath) as normal files with a path.
  classifyBatch: (files: File[]) => {
    const fd = new FormData();
    files.forEach(f => {
      const rel = (f as any).webkitRelativePath;
      if (rel && rel.length > 0) {
        fd.append('files', f, rel);
      } else {
        fd.append('files', f);
      }
    });
    return requestFormData<{
      job_id: string;
      status: string;
      item_count: number;
      expanded_from_zip: number;
    }>('/classify/batch', fd);
  },

  jobStatus: (jobId: string) => request<BatchJobStatus>(`/classify/status/${jobId}`),

  // History & audit
  history: (params: { limit?: number; offset?: number; label?: string; only_overrides?: boolean } = {}) => {
    const qs = new URLSearchParams();
    Object.entries(params).forEach(([k, v]) => v !== undefined && v !== '' && qs.append(k, String(v)));
    return request<{ total: number; offset: number; limit: number; entries: HistoryEntry[] }>(`/history?${qs}`);
  },
  document: (docId: string) =>
    request<{ audit: any; overrides: any[]; approvals: any[] }>(`/document/${docId}`),

  // HITL
  override: (body: { doc_id: string; original_label: string; corrected_label: string; reviewer: string; reason?: string }) =>
    request<{ status: string; is_correction: boolean; entry: any }>('/override', {
      method: 'POST',
      body: JSON.stringify(body),
    }),
  reviewQueue: () => request<{ pending_count: number; entries: any[] }>('/review-queue'),

  // Approvals
  approve: (body: { doc_id: string; approver: string; decision: string; notes?: string }) =>
    request<{ status: string; entry: any; gate_status: any }>('/approval/sign-off', {
      method: 'POST',
      body: JSON.stringify(body),
    }),
  approvalStatus: (docId: string) => request<any>(`/approval/status/${docId}`),

  // Metrics & MLOps
  metrics: () => request<MetricsResponse>('/metrics'),

  mlopsRegistry: () => request<any>('/mlops/registry'),

  mlopsDrift: () =>
    request<{
      status?: string;
      message?: string;
      records_available?: number;
      records_needed?: number;
      psi_score?: number;
      drift_detected?: boolean;
      drift_critical?: boolean;
      confidence_drop?: number;
      label_distribution?: { reference: Record<string, number>; current: Record<string, number> };
      avg_confidence?: { reference: number; current: number };
      recommendation?: string;
      html_report?: string | null;
      computed_at: string;
    }>('/mlops/drift'),

  mlopsAudit: (limit = 100) =>
    request<{ total: number; returned: number; entries: any[] }>(`/mlops/audit?limit=${limit}`),

  mlopsRetraining: () =>
    request<{
      pending_overrides_count: number;
      drift_trigger?: any;
      [k: string]: any;
    }>('/mlops/retraining'),

  mlopsRetrain: () =>
    request<{
      status: string;
      reason: string;
      requested_at: string;
      batch_path?: string;
      next_step: string;
    }>('/mlops/retrain', { method: 'POST' }),

  exportTrainingBatch: () =>
    request<{ exported: boolean; path?: string; pending_count?: number; reason?: string }>(
      '/mlops/export-batch',
      { method: 'POST' },
    ),
};

// ─────────────────────────────────────────────────────────────
// UI helpers — kept here so every component renders the same way
// ─────────────────────────────────────────────────────────────

export function labelClass(label: string | undefined): string {
  switch (label) {
    case 'Public':       return 'label-public';
    case 'Internal':     return 'label-internal';
    case 'Confidential': return 'label-confidential';
    case 'Restricted':   return 'label-restricted';
    default:             return 'bg-slate-100 text-slate-700 border-slate-200';
  }
}

export function actionClass(action: string | undefined): string {
  switch (action) {
    case 'Allow':       return 'bg-emerald-50 text-emerald-700 border-emerald-200';
    case 'Encrypt':     return 'bg-amber-50   text-amber-700   border-amber-200';
    case 'Restrict':    return 'bg-orange-50  text-orange-700  border-orange-200';
    case 'Quarantine':  return 'bg-rose-50    text-rose-700    border-rose-200';
    case 'HumanReview': return 'bg-violet-50  text-violet-700  border-violet-200';
    default:            return 'bg-slate-50   text-slate-700   border-slate-200';
  }
}
