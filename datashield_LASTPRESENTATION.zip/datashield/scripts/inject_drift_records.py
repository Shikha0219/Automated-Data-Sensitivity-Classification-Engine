"""
inject_drift_records.py
-----------------------
Appends ~40 drift-inducing audit records to logs/audit.jsonl.

Drift strategy:
  - Reference window (first 50 rows) is ~85% Restricted.
  - New records skew heavily toward Public / Internal with LOW confidence
    and frequent label flips (pre_policy_label != post_policy_label).
  - This pushes PSI well above 0.25 → triggers RETRAIN IMMEDIATELY.
"""

import json
import uuid
import os
from datetime import datetime, timezone, timedelta

AUDIT_PATH = os.path.join(os.path.dirname(__file__), '..', 'logs', 'audit.jsonl')

CALIB_SRC = {
    "calibration_script": "scripts/calibrate_thresholds.py",
    "dataset": "data/synthetic_dataset.csv",
    "description": (
        "Thresholds derived from precision-recall analysis on the validation set "
        "using scripts/calibrate_thresholds.py. The restricted_override_prob is set "
        "to maximize recall while maintaining precision >= 0.90. The "
        "confidential_escalate_prob maximizes F1 for Confidential class. The "
        "low_confidence_prob is the lowest threshold where top-class accuracy stays "
        "above 0.80. All values are data-driven, NOT hand-picked.\n"
    ),
    "method": "precision_recall_sweep",
}

BASE_TS = datetime(2026, 5, 16, 0, 0, 0, tzinfo=timezone.utc)


def ts(offset_minutes: int) -> str:
    return (BASE_TS + timedelta(minutes=offset_minutes)).strftime("%Y-%m-%dT%H:%M:%S.%f") + "Z"


def make_public_low_conf(offset: int) -> dict:
    """Public prediction but model is uncertain — used to be Internal in ref window."""
    return {
        "class_probabilities": {"Confidential": 0.1812, "Internal": 0.3541, "Public": 0.4102, "Restricted": 0.0545},
        "confidence": 0.4102,
        "doc_id": str(uuid.uuid4()),
        "evidence_count": 3,
        "input_snippet_masked": "General company announcement about office hours update.",
        "label": "Public",
        "model_contributions": {"logistic": 0.3821, "transformer": None, "xgboost": 0.4383},
        "model_version": "v3.0.0-bilingual",
        "policy_trace": {
            "action": "Allow",
            "approval": {
                "approvals_received": {},
                "is_fully_approved": True,
                "notes": ["Label 'Public' does not require approval."],
                "pending_approvers": [],
                "required_approvers": [],
                "status": "not_required",
            },
            "calibration_source": CALIB_SRC,
            "conflict_resolution": {
                "fired_rules": [
                    {"action": "Allow", "outcome": "Public", "priority": 20,
                     "reason": "Model predicted Public", "rule": "MODEL_PREDICTION"},
                ],
                "winning_rule": "MODEL_PREDICTION",
            },
            "note": "",
            "pii_hits": [],
            "post_policy_label": "Public",
            "pre_policy_label": "Internal",
            "triggered_rules": ["LOW_CONFIDENCE<0.5"],
        },
        "timestamp_utc": ts(offset),
    }


def make_internal_misclassified(offset: int) -> dict:
    """Internal doc that model wobbles on — pre was Confidential, policy overrode."""
    return {
        "class_probabilities": {"Confidential": 0.3314, "Internal": 0.5023, "Public": 0.1421, "Restricted": 0.0242},
        "confidence": 0.5023,
        "doc_id": str(uuid.uuid4()),
        "evidence_count": 4,
        "input_snippet_masked": "Q3 roadmap discussion — internal only. No customer data.",
        "label": "Internal",
        "model_contributions": {"logistic": 0.4712, "transformer": None, "xgboost": 0.5334},
        "model_version": "v3.0.0-bilingual",
        "policy_trace": {
            "action": "Allow",
            "approval": {
                "approvals_received": {},
                "is_fully_approved": True,
                "notes": ["Label 'Internal' does not require approval."],
                "pending_approvers": [],
                "required_approvers": [],
                "status": "not_required",
            },
            "calibration_source": CALIB_SRC,
            "conflict_resolution": {
                "fired_rules": [
                    {"action": "Encrypt", "outcome": "Confidential", "priority": 60,
                     "reason": "Confidential keywords detected: ['roadmap'] | Overrode conflicting rules: ['MODEL_PREDICTION']",
                     "rule": "KEYWORD_CONFIDENTIAL"},
                    {"action": "Allow", "outcome": "Internal", "priority": 20,
                     "reason": "Model predicted Internal", "rule": "MODEL_PREDICTION"},
                ],
                "winning_rule": "MODEL_PREDICTION",
            },
            "note": "",
            "pii_hits": [],
            "post_policy_label": "Internal",
            "pre_policy_label": "Confidential",
            "triggered_rules": ["LOW_CONFIDENCE<0.6"],
        },
        "timestamp_utc": ts(offset),
    }


def make_public_high_conf(offset: int) -> dict:
    """High-confidence Public — strong drift from Restricted reference."""
    return {
        "class_probabilities": {"Confidential": 0.0082, "Internal": 0.0631, "Public": 0.9211, "Restricted": 0.0076},
        "confidence": 0.9211,
        "doc_id": str(uuid.uuid4()),
        "evidence_count": 5,
        "input_snippet_masked": "Blog post: 5 tips for staying productive while working from home.",
        "label": "Public",
        "model_contributions": {"logistic": 0.8943, "transformer": None, "xgboost": 0.9479},
        "model_version": "v3.0.0-bilingual",
        "policy_trace": {
            "action": "Allow",
            "approval": {
                "approvals_received": {},
                "is_fully_approved": True,
                "notes": ["Label 'Public' does not require approval."],
                "pending_approvers": [],
                "required_approvers": [],
                "status": "not_required",
            },
            "calibration_source": CALIB_SRC,
            "conflict_resolution": {
                "fired_rules": [
                    {"action": "Allow", "outcome": "Public", "priority": 20,
                     "reason": "Model predicted Public", "rule": "MODEL_PREDICTION"},
                ],
                "winning_rule": "MODEL_PREDICTION",
            },
            "note": "",
            "pii_hits": [],
            "post_policy_label": "Public",
            "pre_policy_label": "Public",
            "triggered_rules": [],
        },
        "timestamp_utc": ts(offset),
    }


def make_internal_high_conf(offset: int) -> dict:
    """High-confidence Internal — away from Restricted."""
    return {
        "class_probabilities": {"Confidential": 0.0031, "Internal": 0.9871, "Public": 0.0064, "Restricted": 0.0034},
        "confidence": 0.9871,
        "doc_id": str(uuid.uuid4()),
        "evidence_count": 5,
        "input_snippet_masked": "Sprint planning notes for the backend team — week of May 19.",
        "label": "Internal",
        "model_contributions": {"logistic": 0.9721, "transformer": None, "xgboost": 0.9943},
        "model_version": "v3.0.0-bilingual",
        "policy_trace": {
            "action": "Allow",
            "approval": {
                "approvals_received": {},
                "is_fully_approved": True,
                "notes": ["Label 'Internal' does not require approval."],
                "pending_approvers": [],
                "required_approvers": [],
                "status": "not_required",
            },
            "calibration_source": CALIB_SRC,
            "conflict_resolution": {
                "fired_rules": [
                    {"action": "Allow", "outcome": "Internal", "priority": 20,
                     "reason": "Model predicted Internal", "rule": "MODEL_PREDICTION"},
                ],
                "winning_rule": "MODEL_PREDICTION",
            },
            "note": "",
            "pii_hits": [],
            "post_policy_label": "Internal",
            "pre_policy_label": "Internal",
            "triggered_rules": [],
        },
        "timestamp_utc": ts(offset),
    }


def make_confidential_flip(offset: int) -> dict:
    """Model said Restricted but policy says Confidential — signals confusion."""
    return {
        "class_probabilities": {"Confidential": 0.2841, "Internal": 0.1234, "Public": 0.0312, "Restricted": 0.5613},
        "confidence": 0.2841,
        "doc_id": str(uuid.uuid4()),
        "evidence_count": 4,
        "input_snippet_masked": "Executive bonus structure for FY2025 — HR eyes only.",
        "label": "Confidential",
        "model_contributions": {"logistic": 0.2134, "transformer": None, "xgboost": 0.5881},
        "model_version": "v3.0.0-bilingual",
        "policy_trace": {
            "action": "HumanReview",
            "approval": {
                "approvals_received": {},
                "is_fully_approved": False,
                "notes": [
                    "Label 'Confidential' requires approval from: ['Legal'].",
                    "Action is BLOCKED until all approvers sign off.",
                ],
                "pending_approvers": ["Legal"],
                "required_approvers": ["Legal"],
                "status": "pending",
            },
            "calibration_source": CALIB_SRC,
            "conflict_resolution": {
                "fired_rules": [
                    {"action": "Quarantine", "outcome": "Restricted", "priority": 20,
                     "reason": "Model predicted Restricted", "rule": "MODEL_PREDICTION"},
                    {"action": "Encrypt", "outcome": "Confidential", "priority": 60,
                     "reason": "Confidential keywords detected: ['bonus', 'executive', 'HR'] | Overrode: ['MODEL_PREDICTION']",
                     "rule": "KEYWORD_CONFIDENTIAL"},
                ],
                "winning_rule": "KEYWORD_CONFIDENTIAL",
            },
            "note": "Confidential keyword(s) found: ['bonus', 'executive', 'HR']",
            "pii_hits": [],
            "post_policy_label": "Confidential",
            "pre_policy_label": "Restricted",
            "triggered_rules": ["KEYWORD_CONFIDENTIAL:bonus", "LOW_CONFIDENCE<0.5"],
        },
        "timestamp_utc": ts(offset),
    }


def make_very_low_conf_public(offset: int) -> dict:
    """Very low confidence — model barely picks Public. Pulls avg confidence down."""
    return {
        "class_probabilities": {"Confidential": 0.2391, "Internal": 0.3012, "Public": 0.3318, "Restricted": 0.1279},
        "confidence": 0.3318,
        "doc_id": str(uuid.uuid4()),
        "evidence_count": 2,
        "input_snippet_masked": "Short unlabelled text snippet submitted by user.",
        "label": "Public",
        "model_contributions": {"logistic": 0.2891, "transformer": None, "xgboost": 0.3745},
        "model_version": "v3.0.0-bilingual",
        "policy_trace": {
            "action": "Allow",
            "approval": {
                "approvals_received": {},
                "is_fully_approved": True,
                "notes": ["Label 'Public' does not require approval."],
                "pending_approvers": [],
                "required_approvers": [],
                "status": "not_required",
            },
            "calibration_source": CALIB_SRC,
            "conflict_resolution": {
                "fired_rules": [
                    {"action": "Allow", "outcome": "Public", "priority": 20,
                     "reason": "Model predicted Public", "rule": "MODEL_PREDICTION"},
                ],
                "winning_rule": "MODEL_PREDICTION",
            },
            "note": "",
            "pii_hits": [],
            "post_policy_label": "Public",
            "pre_policy_label": "Internal",
            "triggered_rules": ["LOW_CONFIDENCE<0.5"],
        },
        "timestamp_utc": ts(offset),
    }


# Build 40 records: heavy on Public + Internal, sprinkle Confidential flips
records = []
offset = 1

pattern = [
    make_public_high_conf,       # 1
    make_public_high_conf,       # 2
    make_internal_high_conf,     # 3
    make_public_low_conf,        # 4
    make_internal_misclassified, # 5
    make_public_high_conf,       # 6
    make_very_low_conf_public,   # 7
    make_internal_high_conf,     # 8
    make_confidential_flip,      # 9
    make_public_high_conf,       # 10
    make_public_low_conf,        # 11
    make_internal_high_conf,     # 12
    make_public_high_conf,       # 13
    make_very_low_conf_public,   # 14
    make_internal_misclassified, # 15
    make_public_high_conf,       # 16
    make_internal_high_conf,     # 17
    make_public_low_conf,        # 18
    make_confidential_flip,      # 19
    make_public_high_conf,       # 20
    make_internal_high_conf,     # 21
    make_public_high_conf,       # 22
    make_very_low_conf_public,   # 23
    make_public_low_conf,        # 24
    make_internal_high_conf,     # 25
    make_public_high_conf,       # 26
    make_internal_misclassified, # 27
    make_public_high_conf,       # 28
    make_confidential_flip,      # 29
    make_internal_high_conf,     # 30
    make_public_high_conf,       # 31
    make_very_low_conf_public,   # 32
    make_public_low_conf,        # 33
    make_internal_high_conf,     # 34
    make_public_high_conf,       # 35
    make_internal_misclassified, # 36
    make_very_low_conf_public,   # 37
    make_public_high_conf,       # 38
    make_internal_high_conf,     # 39
    make_confidential_flip,      # 40
]

for fn in pattern:
    records.append(fn(offset))
    offset += 2

# Append to audit.jsonl
audit_path = os.path.abspath(AUDIT_PATH)
with open(audit_path, 'a', encoding='utf-8') as f:
    for rec in records:
        f.write(json.dumps(rec) + '\n')

print(f"[inject_drift] Appended {len(records)} drift-inducing records to {audit_path}")

# Quick summary
from collections import Counter
labels = Counter(r['label'] for r in records)
avg_conf = sum(r['confidence'] for r in records) / len(records)
print(f"[inject_drift] Label distribution: {dict(labels)}")
print(f"[inject_drift] Avg confidence of new records: {avg_conf:.4f}")
print("[inject_drift] Done — run mlops.py to see drift report.")
