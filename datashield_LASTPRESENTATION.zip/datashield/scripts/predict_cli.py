"""
predict_cli.py
--------------
Run the classification pipeline on one file or a folder of files.

Usage:
    # Single file
    python -m scripts.predict_cli --input sample.txt

    # Folder (walks recursively)
    python -m scripts.predict_cli --input data/sample_docs/

    # Write results to JSONL
    python -m scripts.predict_cli --input data/sample_docs/ --output logs/results.jsonl

    # Pretty-print to stdout
    python -m scripts.predict_cli --input sample.txt --pretty
"""
import argparse
import json
import os
import sys
import time

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from pipeline import SensitivityClassifier
from utils.io_helpers import read_documents, write_jsonl


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--input', required=True, help='File or folder path')
    parser.add_argument('--output', help='JSONL output path (default: print to stdout)')
    parser.add_argument('--pretty', action='store_true', help='Pretty-print single result')
    parser.add_argument('--model-config', default='configs/model.yaml')
    parser.add_argument('--policy-config', default='configs/policy.yaml')
    args = parser.parse_args()

    clf = SensitivityClassifier(
        model_config=args.model_config,
        policy_config=args.policy_config,
    )

    texts = []
    metadatas = []
    for text, meta in read_documents(args.input):
        if not text.strip():
            continue
        texts.append(text)
        metadatas.append(meta)

    if not texts:
        print('[predict] no valid input documents found')
        sys.exit(1)

    print(f'[predict] classifying {len(texts)} document(s)...')
    t0 = time.time()
    results = clf.predict_batch(texts, metadatas)
    elapsed_ms = (time.time() - t0) * 1000
    per_doc_ms = elapsed_ms / len(results)
    print(f'[predict] done in {elapsed_ms:.1f} ms total ({per_doc_ms:.1f} ms/doc)')

    if args.output:
        write_jsonl(results, args.output)
        print(f'[predict] wrote {len(results)} results to {args.output}')
    elif args.pretty and len(results) == 1:
        print(json.dumps(results[0], indent=2, sort_keys=True, ensure_ascii=False))
    else:
        for r in results:
            print(json.dumps(r, sort_keys=True, ensure_ascii=False))


if __name__ == '__main__':
    main()
