"""
language_detector.py
--------------------
Detects language by Unicode script rather than running a heavy model.

Why script-based and not langdetect/fasttext:
  - Hindi is written in Devanagari (Unicode range U+0900-U+097F).
  - English uses ASCII Latin letters.
  - For financial/HR documents we only care about these two right now.
  - Script-based detection is O(n) over characters, adds <0.1 ms per doc,
    is deterministic (auditable!), and has no model dependency.

Returns one of: 'en', 'hi', 'unknown'.
'unknown' is returned for very short text or mixed scripts we can't classify.
The pipeline routes 'unknown' through the English model (safest default).
"""

DEVANAGARI_START = 0x0900
DEVANAGARI_END = 0x097F


def _count_scripts(text: str):
    latin = 0
    devanagari = 0
    for ch in text:
        cp = ord(ch)
        if 0x0041 <= cp <= 0x005A or 0x0061 <= cp <= 0x007A:
            latin += 1
        elif DEVANAGARI_START <= cp <= DEVANAGARI_END:
            devanagari += 1
    return latin, devanagari


def detect_language(text: str) -> str:
    """
    Returns 'en', 'hi', or 'unknown'.

    Rules:
      - If Devanagari chars are >= 15% of letter chars → 'hi'
      - Else if Latin chars dominate (>85% of letters) → 'en'
      - Else 'unknown'
    """
    if not text or not text.strip():
        return 'unknown'

    latin, devanagari = _count_scripts(text)
    total_letters = latin + devanagari

    if total_letters == 0:
        return 'unknown'

    dev_ratio = devanagari / total_letters
    if dev_ratio >= 0.15:
        return 'hi'

    latin_ratio = latin / total_letters
    if latin_ratio >= 0.85:
        return 'en'

    return 'unknown'


def language_label(code: str) -> str:
    """Human-readable label for audit logs."""
    return {'en': 'English', 'hi': 'Hindi', 'unknown': 'Unknown'}.get(code, 'Unknown')
