"""
io_helpers.py
-------------
Read text from single files or folders of mixed-format files.

Supported formats out-of-the-box:
  - .txt, .log, .md   → plain read
  - .csv              → concatenate all cells (simple docs-in-CSV scenario)
  - .json, .jsonl     → flatten string fields

Binary formats (PDF/DOCX) are owned by the ingestion teammate (Apache Tika).
If someone passes a PDF here, we raise a clear error directing them to the
ingestion service.
"""
import csv
import json
import os
from pathlib import Path
from typing import Iterator, Tuple, Dict, Any

SUPPORTED_EXT = {'.txt', '.log', '.md', '.csv', '.json', '.jsonl'}
UNSUPPORTED_EXT_MSG = {
    '.pdf': 'PDF parsing is owned by the ingestion layer (Apache Tika). Pass pre-parsed text.',
    '.docx': 'DOCX parsing is owned by the ingestion layer (python-docx). Pass pre-parsed text.',
    '.doc': 'Legacy .doc requires Tika. Use the ingestion service.',
}


def _read_txt(path: Path) -> str:
    with open(path, 'r', encoding='utf-8', errors='replace') as f:
        return f.read()


def _read_csv(path: Path) -> Iterator[Tuple[str, Dict[str, Any]]]:
    """Yields (row_text, row_metadata) for each CSV row."""
    with open(path, 'r', encoding='utf-8', errors='replace', newline='') as f:
        reader = csv.DictReader(f)
        for i, row in enumerate(reader):
            # Prefer a 'text' column if it exists; else concat all values.
            if 'text' in row:
                text = row.get('text', '') or ''
            else:
                text = ' '.join(str(v) for v in row.values() if v)
            meta = {'row_index': i, 'source_file': str(path)}
            # Carry through common metadata columns if present.
            for k in ('source_system', 'department', 'author', 'file_type'):
                if k in row and row[k]:
                    meta[k] = row[k]
            yield text, meta


def _read_json(path: Path) -> Iterator[Tuple[str, Dict[str, Any]]]:
    with open(path, 'r', encoding='utf-8', errors='replace') as f:
        try:
            data = json.load(f)
        except json.JSONDecodeError:
            # try JSONL
            f.seek(0)
            for i, line in enumerate(f):
                line = line.strip()
                if not line:
                    continue
                obj = json.loads(line)
                text = obj.get('text') or json.dumps(obj, ensure_ascii=False)
                yield text, {'line_index': i, 'source_file': str(path)}
            return
        if isinstance(data, list):
            for i, obj in enumerate(data):
                text = obj.get('text') if isinstance(obj, dict) else str(obj)
                meta = {'index': i, 'source_file': str(path)}
                if isinstance(obj, dict):
                    for k in ('source_system', 'department', 'author', 'file_type'):
                        if k in obj:
                            meta[k] = obj[k]
                yield text or '', meta
        elif isinstance(data, dict):
            yield data.get('text', json.dumps(data)), {'source_file': str(path)}


def read_documents(input_path: str) -> Iterator[Tuple[str, Dict[str, Any]]]:
    """
    Yields (text, metadata) for every document found at input_path.
    input_path can be a single file or a directory.
    """
    p = Path(input_path)
    if not p.exists():
        raise FileNotFoundError(f'Input path does not exist: {input_path}')

    if p.is_file():
        yield from _read_single(p)
    else:
        for child in sorted(p.rglob('*')):
            if child.is_file():
                try:
                    yield from _read_single(child)
                except ValueError as e:
                    # Skip unsupported files with a warning metadata rather than crash
                    yield '', {'source_file': str(child), 'skipped_reason': str(e)}


def _read_single(path: Path) -> Iterator[Tuple[str, Dict[str, Any]]]:
    ext = path.suffix.lower()
    if ext in UNSUPPORTED_EXT_MSG:
        raise ValueError(UNSUPPORTED_EXT_MSG[ext])
    if ext not in SUPPORTED_EXT:
        raise ValueError(f'Unsupported extension {ext}; supported: {SUPPORTED_EXT}')

    base_meta = {
        'source_file': str(path),
        'file_type': ext.lstrip('.'),
        'size_bytes': path.stat().st_size,
    }

    if ext in ('.txt', '.log', '.md'):
        yield _read_txt(path), base_meta
    elif ext == '.csv':
        for text, meta in _read_csv(path):
            meta = {**base_meta, **meta}
            yield text, meta
    elif ext in ('.json', '.jsonl'):
        for text, meta in _read_json(path):
            meta = {**base_meta, **meta}
            yield text, meta


def write_jsonl(results, output_path: str):
    """Write a list/iterator of dicts to JSONL, with deterministic key order."""
    os.makedirs(os.path.dirname(output_path) or '.', exist_ok=True)
    with open(output_path, 'w', encoding='utf-8') as f:
        for r in results:
            f.write(json.dumps(r, sort_keys=True, ensure_ascii=False) + '\n')
