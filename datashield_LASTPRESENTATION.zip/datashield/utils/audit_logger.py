"""
audit_logger.py
---------------
Writes one JSON line per prediction to logs/audit.jsonl.

Guarantees:
  - Input snippet is masked before write (compliance C1).
  - Keys are sorted for deterministic output (reproducibility for audit).
  - Every entry has a UTC ISO timestamp and a monotonic doc_id.
  - Log rotation is ops-team responsibility (we just append).
"""
import json
import os
import uuid
from datetime import datetime, timezone
from typing import Any, Dict
from utils.pii_masker import safe_snippet


class AuditLogger:
    def __init__(self, log_dir: str = 'logs', filename: str = 'audit.jsonl'):
        os.makedirs(log_dir, exist_ok=True)
        self.path = os.path.join(log_dir, filename)

    def log(self, input_text: str, prediction: Dict[str, Any], model_version: str = 'v1.0.0') -> str:
        """Writes one audit entry. Returns the doc_id."""
        doc_id = prediction.get('doc_id') or str(uuid.uuid4())
        entry = {
            'doc_id': doc_id,
            'timestamp_utc': datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z'),
            'model_version': model_version,
            'input_snippet_masked': safe_snippet(input_text, max_len=160),
            'label': prediction.get('label'),
            'confidence': prediction.get('confidence'),
            'class_probabilities': prediction.get('class_probabilities'),
            'policy_trace': prediction.get('policy_trace'),
            'model_contributions': prediction.get('model_contributions'),
            'evidence_count': len(prediction.get('evidence', [])),
        }
        with open(self.path, 'a', encoding='utf-8') as f:
            f.write(json.dumps(entry, sort_keys=True, ensure_ascii=False) + '\n')
        return doc_id
