"""
lime_explainer.py
-----------------
LIME explanations for the Logistic Regression pipeline (TF-IDF + LR).

Why LIME here:
  Logistic Regression is technically globally interpretable via its
  coefficients, but coefficients don't account for which tokens are
  actually PRESENT in the current document. LIME perturbs the input
  text and fits a local linear surrogate, giving per-document evidence
  that is more intuitive for audit reviewers.

Fallback:
  If LIME is not installed or fails, we use direct coefficient lookup
  (TF-IDF weight × LR coefficient for the predicted class) which is a
  principled second choice for linear models.
"""
from typing import List, Dict, Any
import numpy as np

try:
    from lime.lime_text import LimeTextExplainer
    LIME_AVAILABLE = True
except ImportError:
    LIME_AVAILABLE = False


class LimeExplainer:
    def __init__(self, logistic_model, top_k: int = 5, num_samples: int = 500):
        """
        logistic_model: instance of models.logistic_model.LogisticModel (fitted)
        """
        self.model = logistic_model
        self.top_k = top_k
        self.num_samples = num_samples
        self._explainer = None
        if LIME_AVAILABLE:
            self._explainer = LimeTextExplainer(
                class_names=logistic_model.classes,
                random_state=42,
            )

    def _predict_proba_for_lime(self, texts: List[str]) -> np.ndarray:
        return self.model.predict_proba(texts)

    def explain(self, text: str, predicted_class: str) -> List[Dict[str, Any]]:
        if not LIME_AVAILABLE or self._explainer is None:
            return self._fallback_explain(text, predicted_class)

        class_idx = self.model.classes.index(predicted_class)
        try:
            exp = self._explainer.explain_instance(
                text,
                self._predict_proba_for_lime,
                num_features=self.top_k,
                num_samples=self.num_samples,
                labels=[class_idx],
            )
            pairs = exp.as_list(label=class_idx)
        except Exception as e:
            print(f'  [lime] explain failed, using fallback: {e}')
            return self._fallback_explain(text, predicted_class)

        evidence = []
        for tok, weight in pairs:
            if weight <= 0:
                continue
            evidence.append({
                'token': tok,
                'weight': round(float(weight), 4),
                'source': 'LIME',
            })
        return evidence[:self.top_k]

    def _fallback_explain(self, text: str, predicted_class: str) -> List[Dict[str, Any]]:
        """Coefficient × TF-IDF weight for tokens present in text."""
        pipeline = self.model.pipeline
        vec = pipeline.named_steps['tfidf']
        clf = pipeline.named_steps['clf']
        X = vec.transform([text])
        feature_names = vec.get_feature_names_out()

        fitted_classes = list(clf.classes_)
        class_idx = fitted_classes.index(predicted_class)

        coefs = clf.coef_[class_idx] if clf.coef_.shape[0] > 1 else clf.coef_[0]
        contrib = X.toarray()[0] * coefs

        order = np.argsort(-contrib)
        evidence = []
        for idx in order:
            if contrib[idx] <= 0:
                break
            evidence.append({
                'token': feature_names[idx],
                'weight': round(float(contrib[idx]), 4),
                'source': 'LIME_fallback',
            })
            if len(evidence) >= self.top_k:
                break
        return evidence
