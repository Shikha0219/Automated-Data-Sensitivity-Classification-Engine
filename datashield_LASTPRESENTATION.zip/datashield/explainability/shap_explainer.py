"""
shap_explainer.py
-----------------
SHAP explanations for the XGBoost model.

Approach:
  - Use TreeExplainer (exact for tree models, fast).
  - For each prediction, compute SHAP values on the hashed-TFIDF + metadata
    feature matrix.
  - Map top-|SHAP| hashed-text feature indices back to the specific n-grams
    in the input text that hash into them. This is the standard technique
    when using HashingVectorizer.
  - Return top-k (token, weight) pairs.

Note on HashingVectorizer + SHAP:
  HashingVectorizer loses the token→index mapping (that's the point), so we
  recompute which input tokens map to each hashed index at explain time.
  Multiple tokens may collide into one hash bucket; we report all of them
  as joint evidence.
"""
from typing import List, Dict, Any, Tuple
import numpy as np

try:
    import shap
    SHAP_AVAILABLE = True
except ImportError:
    SHAP_AVAILABLE = False


class ShapExplainer:
    def __init__(self, xgb_model, top_k: int = 5):
        """
        xgb_model: instance of models.xgboost_model.XGBoostModel (fitted)
        """
        self.model = xgb_model
        self.top_k = top_k
        self._explainer = None
        if SHAP_AVAILABLE:
            try:
                self._explainer = shap.TreeExplainer(xgb_model.clf)
            except Exception as e:
                # Fall back to coefficient-like feature importance
                print(f'  [shap] TreeExplainer init failed, will use feature_importances_ fallback: {e}')
                self._explainer = None

    def _hash_inverse_mapping(self, text: str) -> Dict[int, List[str]]:
        """
        Build {hashed_index: [tokens that hashed to it]} for this text.
        We use the hasher's build_analyzer to get the same token stream.
        """
        hasher = self.model.hasher
        analyzer = hasher.build_analyzer()
        tokens = analyzer(text)
        n_features = hasher.n_features

        # Use the SAME hashing function sklearn uses via transform on singletons.
        # Cheaper path: transform per-token on a batch.
        buckets: Dict[int, List[str]] = {}
        if not tokens:
            return buckets
        # transform returns a sparse matrix; each row has exactly 1-2 non-zero entries
        X = hasher.transform(tokens)
        X = X.tocoo()
        for i, j in zip(X.row, X.col):
            buckets.setdefault(int(j), []).append(tokens[int(i)])
        return buckets

    def explain(self, text: str, metadata: Dict[str, Any], predicted_class: str) -> List[Dict[str, Any]]:
        """
        Returns a list of top-k evidence dicts:
            [{'token': 'ssn', 'weight': 0.42, 'source': 'SHAP'}, ...]
        """
        if not SHAP_AVAILABLE or self._explainer is None:
            return self._fallback_explain(text, predicted_class)

        class_idx = self.model.classes.index(predicted_class)
        X = self.model.get_feature_matrix([text], [metadata])

        try:
            # shap_values: list of arrays (one per class) for multi-class tree models
            shap_values = self._explainer.shap_values(X)
            if isinstance(shap_values, list):
                sv = shap_values[class_idx][0]   # (n_features,)
            else:
                # newer SHAP: ndarray (n_samples, n_features, n_classes)
                sv = shap_values[0, :, class_idx] if shap_values.ndim == 3 else shap_values[0]
        except Exception as e:
            print(f'  [shap] explain failed, using fallback: {e}')
            return self._fallback_explain(text, predicted_class)

        hash_dim = self.model.hash_features
        text_sv = sv[:hash_dim]
        # We care about POSITIVE contribution toward predicted_class
        order = np.argsort(-text_sv)

        inverse = self._hash_inverse_mapping(text)
        evidence: List[Dict[str, Any]] = []
        seen_tokens = set()

        for idx in order:
            if text_sv[idx] <= 0:
                break
            tokens = inverse.get(int(idx), [])
            for tok in tokens:
                if tok in seen_tokens:
                    continue
                seen_tokens.add(tok)
                evidence.append({
                    'token': tok,
                    'weight': round(float(text_sv[idx]), 4),
                    'source': 'SHAP',
                })
                if len(evidence) >= self.top_k:
                    return evidence
            if len(evidence) >= self.top_k:
                break
        return evidence

    def _fallback_explain(self, text: str, predicted_class: str) -> List[Dict[str, Any]]:
        """If SHAP fails, return top tokens by raw XGBoost gain importance."""
        try:
            importances = self.model.clf.feature_importances_
            hash_dim = self.model.hash_features
            text_imp = importances[:hash_dim]
            order = np.argsort(-text_imp)
            inverse = self._hash_inverse_mapping(text)
            evidence = []
            seen = set()
            for idx in order:
                tokens = inverse.get(int(idx), [])
                for tok in tokens:
                    if tok in seen or not tok:
                        continue
                    seen.add(tok)
                    evidence.append({
                        'token': tok,
                        'weight': round(float(text_imp[idx]), 4),
                        'source': 'SHAP_fallback',
                    })
                    if len(evidence) >= self.top_k:
                        return evidence
            return evidence
        except Exception:
            return []
