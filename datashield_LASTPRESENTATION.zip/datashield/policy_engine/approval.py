"""
approval.py
-----------
Dual-approval gate for sensitive policy actions.

Design:
  - Restricted actions REQUIRE sign-off from BOTH Legal AND DataGovernance.
  - Confidential actions require ONLY Legal approval.
  - Public / Internal → auto-approved, no gate.

  This module simulates the approval workflow. In production the approvals
  would come from an external IAM / ticketing system (ServiceNow, JIRA).
  For our standalone module, we model the approval states so the output
  contract includes the correct `approval_status` and `required_approvers`.

  Integration point for Aditi's API module:
    The API layer will expose an endpoint for approvers to POST their
    sign-off. This module provides the data model and validation logic.

Rule Conflict Resolution:
  When multiple policy rules fire on the same document, we resolve conflicts
  using a priority-based system (configured in policy.yaml under
  `rule_priorities`). Higher priority wins. If two rules have equal priority,
  the MORE restrictive outcome wins (Restricted > Confidential > Internal > Public).
"""
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional
from enum import Enum


# ============================================================
# Approval status model
# ============================================================

class ApprovalStatus(Enum):
    NOT_REQUIRED = "not_required"
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"


@dataclass
class ApprovalGate:
    """Tracks who needs to approve and current status."""
    required_approvers: List[str] = field(default_factory=list)
    approvals_received: Dict[str, str] = field(default_factory=dict)  # approver → status
    status: ApprovalStatus = ApprovalStatus.NOT_REQUIRED
    notes: List[str] = field(default_factory=list)

    @property
    def is_fully_approved(self) -> bool:
        if self.status == ApprovalStatus.NOT_REQUIRED:
            return True
        return all(
            self.approvals_received.get(a) == 'approved'
            for a in self.required_approvers
        )

    @property
    def pending_approvers(self) -> List[str]:
        return [
            a for a in self.required_approvers
            if self.approvals_received.get(a) != 'approved'
        ]

    def record_approval(self, approver: str, decision: str = 'approved') -> bool:
        """
        Record an approval/rejection from an approver.
        Returns True if the overall gate is now fully approved.
        """
        if approver not in self.required_approvers:
            self.notes.append(f"Approver '{approver}' is not in required list. Ignored.")
            return False

        self.approvals_received[approver] = decision
        if decision == 'rejected':
            self.status = ApprovalStatus.REJECTED
            self.notes.append(f"{approver} REJECTED the action.")
            return False

        if self.is_fully_approved:
            self.status = ApprovalStatus.APPROVED
            self.notes.append("All required approvals received.")
            return True

        self.notes.append(f"{approver} approved. Waiting on: {self.pending_approvers}")
        return False

    def to_dict(self) -> Dict[str, Any]:
        return {
            'required_approvers': self.required_approvers,
            'approvals_received': dict(self.approvals_received),
            'status': self.status.value,
            'is_fully_approved': self.is_fully_approved,
            'pending_approvers': self.pending_approvers,
            'notes': self.notes,
        }


# ============================================================
# Approval requirement lookup
# ============================================================

# Default approval requirements per label
DEFAULT_APPROVAL_MAP = {
    'Public': {
        'requires_approval': False,
        'approvers': [],
    },
    'Internal': {
        'requires_approval': False,
        'approvers': [],
    },
    'Confidential': {
        'requires_approval': True,
        'approvers': ['Legal'],
    },
    'Restricted': {
        'requires_approval': True,
        'approvers': ['Legal', 'DataGovernance'],  # DUAL APPROVAL
    },
}


def build_approval_gate(
    label: str,
    approval_config: Optional[Dict[str, Any]] = None,
) -> ApprovalGate:
    """
    Build an ApprovalGate for the given classification label.

    Uses approval_config from policy.yaml if provided, otherwise
    falls back to DEFAULT_APPROVAL_MAP.
    """
    config = approval_config or DEFAULT_APPROVAL_MAP
    entry = config.get(label, {'requires_approval': False, 'approvers': []})

    if not entry.get('requires_approval', False):
        return ApprovalGate(
            status=ApprovalStatus.NOT_REQUIRED,
            notes=[f"Label '{label}' does not require approval."],
        )

    approvers = entry.get('approvers', [])
    gate = ApprovalGate(
        required_approvers=list(approvers),
        status=ApprovalStatus.PENDING,
        notes=[
            f"Label '{label}' requires approval from: {approvers}.",
            f"Action is BLOCKED until all approvers sign off.",
        ],
    )
    return gate


# ============================================================
# Rule conflict resolution
# ============================================================

# Sensitivity ordering: higher index = more sensitive
SENSITIVITY_ORDER = {
    'Public': 0,
    'Internal': 1,
    'Confidential': 2,
    'Restricted': 3,
}

# Default rule priorities (higher = takes precedence)
DEFAULT_RULE_PRIORITIES = {
    'PII_REGEX_HIGH': 100,        # High-severity PII (SSN, card, IBAN, PAN, Aadhaar)
    'PII_AGGREGATE_MEDIUM': 90,   # Multiple medium PII hits aggregated
    'THRESHOLD_RESTRICTED': 80,   # Model P(Restricted) > threshold
    'KEYWORD_CONFIDENTIAL': 60,   # Confidential keyword found
    'CONFIDENTIAL_ESCALATE': 50,  # Confidential escalation threshold
    'LOW_CONFIDENCE': 40,         # Low confidence → human review
    'MODEL_PREDICTION': 20,       # Base model prediction (lowest)
}


@dataclass
class ResolvedRule:
    """One fired rule with its priority and outcome."""
    rule_name: str
    priority: int
    outcome_label: str
    outcome_action: str
    reason: str


def resolve_conflicts(
    fired_rules: List[ResolvedRule],
    rule_priorities: Optional[Dict[str, int]] = None,
) -> ResolvedRule:
    """
    Given a list of fired rules, resolve conflicts:
      1. Sort by priority (descending)
      2. Ties broken by sensitivity level (more restrictive wins)
      3. Return the winning rule

    This implements the problem statement requirement:
      "Rule conflict resolution mechanism defined"
    """
    if not fired_rules:
        return ResolvedRule(
            rule_name='DEFAULT',
            priority=0,
            outcome_label='Public',
            outcome_action='Allow',
            reason='No rules fired; defaulting to least restrictive.',
        )

    # Sort: higher priority first, then higher sensitivity
    sorted_rules = sorted(
        fired_rules,
        key=lambda r: (
            r.priority,
            SENSITIVITY_ORDER.get(r.outcome_label, 0),
        ),
        reverse=True,
    )

    winner = sorted_rules[0]

    # Annotate if there were conflicts
    if len(sorted_rules) > 1 and sorted_rules[1].outcome_label != winner.outcome_label:
        conflicts = [r.rule_name for r in sorted_rules[1:] if r.outcome_label != winner.outcome_label]
        winner.reason += f" | Overrode conflicting rules: {conflicts}"

    return winner
