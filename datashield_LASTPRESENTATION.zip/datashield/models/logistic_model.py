"""
logistic_model.py
-----------------
Baseline: TF-IDF (word n-grams 1-2) + Logistic Regression.

Role in ensemble:
  - Fast, interpretable baseline
  - Strong on keyword-dominated signals (e.g. "salary", "SSN")
  - Class-weighted to handle Restricted class rarity even after oversampling

Explainability: LIME (see explainability/lime_explainer.py)
"""
import os
import joblib
import numpy as np
from typing import List, Dict, Any
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline


class LogisticModel:
    def __init__(self, cfg: Dict[str, Any], classes: List[str]):
        self.classes = classes
        tfidf_cfg = cfg.get('tfidf', {})
        model_cfg = cfg.get('model', {})

        self.pipeline: Pipeline = Pipeline([
            ('tfidf', TfidfVectorizer(
                ngram_range=tuple(tfidf_cfg.get('ngram_range', [1, 2])),
                max_features=tfidf_cfg.get('max_features', 20000),
                min_df=tfidf_cfg.get('min_df', 2),
                sublinear_tf=tfidf_cfg.get('sublinear_tf', True),
                lowercase=True,
            )),
            ('clf', LogisticRegression(
                C=model_cfg.get('C', 1.0),
                max_iter=model_cfg.get('max_iter', 1000),
                class_weight=model_cfg.get('class_weight', 'balanced'),
                solver=model_cfg.get('solver', 'liblinear'),
                # multi_class='auto' was removed in sklearn 1.7+; it's now the default behavior.
                random_state=42,
            )),
        ])

    def fit(self, texts: List[str], labels: List[str]):
        self.pipeline.fit(texts, labels)
        return self

    def predict_proba(self, texts: List[str]) -> np.ndarray:
        """Returns probs in the order of self.classes_ from the fitted model."""
        probs = self.pipeline.predict_proba(texts)
        # Reorder to match self.classes (our canonical order)
        fitted_classes = list(self.pipeline.named_steps['clf'].classes_)
        reorder = [fitted_classes.index(c) for c in self.classes]
        return probs[:, reorder]

    def predict(self, texts: List[str]) -> List[str]:
        probs = self.predict_proba(texts)
        idx = np.argmax(probs, axis=1)
        return [self.classes[i] for i in idx]

    def save(self, path: str):
        os.makedirs(os.path.dirname(path), exist_ok=True)
        joblib.dump({'pipeline': self.pipeline, 'classes': self.classes}, path)

    @classmethod
    def load(cls, path: str, cfg: Dict[str, Any] = None) -> 'LogisticModel':
        obj = joblib.load(path)
        inst = cls.__new__(cls)
        inst.pipeline = obj['pipeline']
        inst.classes = obj['classes']
        return inst
