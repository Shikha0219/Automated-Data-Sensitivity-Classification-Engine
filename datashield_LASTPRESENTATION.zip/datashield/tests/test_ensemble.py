"""
test_ensemble.py
----------------
Unit tests for the ensemble layer.

Covers:
  - Soft voting basic combination
  - Weight redistribution when a model is missing
  - Graceful fallback when ALL models fail
  - Stacking fit + predict round-trip
  - Degenerate uniform-prior detection
"""
import os
import sys
import numpy as np
import pytest

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from ensemble.voting import SoftVotingEnsemble
from ensemble.stacking import StackingEnsemble


CLASSES = ['Public', 'Internal', 'Confidential', 'Restricted']


# ----------------------------------------------------------------
# Soft Voting
# ----------------------------------------------------------------
def test_soft_voting_basic_combination():
    voter = SoftVotingEnsemble(
        weights={'logistic': 0.5, 'xgboost': 0.5},
        classes=CLASSES,
    )
    lr_probs = np.array([[0.1, 0.2, 0.3, 0.4]])
    xgb_probs = np.array([[0.4, 0.3, 0.2, 0.1]])
    combined = voter.combine({'logistic': lr_probs, 'xgboost': xgb_probs})
    # Equal weights → average
    expected = np.array([[0.25, 0.25, 0.25, 0.25]])
    np.testing.assert_allclose(combined, expected, atol=1e-6)


def test_soft_voting_weighted_combination():
    voter = SoftVotingEnsemble(
        weights={'logistic': 0.25, 'xgboost': 0.75},
        classes=CLASSES,
    )
    lr_probs = np.array([[0.0, 0.0, 0.0, 1.0]])
    xgb_probs = np.array([[1.0, 0.0, 0.0, 0.0]])
    combined = voter.combine({'logistic': lr_probs, 'xgboost': xgb_probs})
    # 0.25 * [0,0,0,1] + 0.75 * [1,0,0,0] = [0.75, 0, 0, 0.25]
    assert np.argmax(combined[0]) == 0   # XGBoost class dominates
    assert combined[0][0] == pytest.approx(0.75, abs=1e-5)
    assert combined[0][3] == pytest.approx(0.25, abs=1e-5)


def test_soft_voting_redistributes_on_missing_model():
    voter = SoftVotingEnsemble(
        weights={'logistic': 0.3, 'xgboost': 0.3, 'transformer': 0.4},
        classes=CLASSES,
    )
    lr_probs = np.array([[1.0, 0.0, 0.0, 0.0]])
    xgb_probs = np.array([[1.0, 0.0, 0.0, 0.0]])
    # transformer missing
    combined = voter.combine({
        'logistic': lr_probs,
        'xgboost': xgb_probs,
        'transformer': None,
    })
    # Both active predict class 0 → should still be class 0
    assert np.argmax(combined[0]) == 0
    # And probs should sum to 1
    assert combined[0].sum() == pytest.approx(1.0, abs=1e-6)


def test_soft_voting_all_failed_returns_uniform():
    voter = SoftVotingEnsemble(
        weights={'logistic': 0.5, 'xgboost': 0.5},
        classes=CLASSES,
    )
    # Both None - simulate total failure
    combined = voter.combine({
        'logistic': None,
        'xgboost': np.array([[0.25, 0.25, 0.25, 0.25]]),  # uniform = degenerate
    })
    # Should fall back to uniform
    np.testing.assert_allclose(combined, np.full((1, 4), 0.25), atol=1e-6)


def test_active_models_excludes_uniform_and_none():
    voter = SoftVotingEnsemble(weights={'a': 0.5, 'b': 0.5}, classes=CLASSES)
    probs = {
        'a': np.array([[0.7, 0.1, 0.1, 0.1]]),
        'b': np.array([[0.25, 0.25, 0.25, 0.25]]),   # degenerate
    }
    assert voter.active_models(probs) == ['a']


# ----------------------------------------------------------------
# Stacking
# ----------------------------------------------------------------
def test_stacking_fit_predict_roundtrip():
    """Build a tiny OOF dataset and verify the meta-learner works end-to-end."""
    rng = np.random.RandomState(42)
    n = 200

    # Generate synthetic labels (balanced)
    labels = np.tile(np.arange(4), n // 4)
    rng.shuffle(labels)

    # Two base models with noisy but informative OOF probs
    oof_a = np.zeros((n, 4))
    oof_b = np.zeros((n, 4))
    for i, c in enumerate(labels):
        oof_a[i] = rng.dirichlet(np.ones(4) + (np.arange(4) == c) * 3)
        oof_b[i] = rng.dirichlet(np.ones(4) + (np.arange(4) == c) * 2)

    stacker = StackingEnsemble(classes=CLASSES, n_folds=5, meta='logistic_regression')
    stacker.fit_meta({'logistic': oof_a, 'xgboost': oof_b}, labels)

    # Predict on training data — should have high accuracy since labels encode signal
    preds = stacker.predict_proba({'logistic': oof_a, 'xgboost': oof_b})
    assert preds.shape == (n, 4)
    assert np.allclose(preds.sum(axis=1), 1.0, atol=1e-5)
    pred_labels = np.argmax(preds, axis=1)
    acc = (pred_labels == labels).mean()
    # With clear signal the meta-learner should easily get > 0.7 accuracy
    assert acc > 0.7


def test_stacking_handles_missing_model_at_inference():
    """If a base model is missing at inference time, stacker should still work."""
    rng = np.random.RandomState(42)
    n = 100
    labels = np.tile(np.arange(4), n // 4)
    rng.shuffle(labels)

    oof_a = np.zeros((n, 4))
    oof_b = np.zeros((n, 4))
    for i, c in enumerate(labels):
        oof_a[i] = rng.dirichlet(np.ones(4) + (np.arange(4) == c) * 3)
        oof_b[i] = rng.dirichlet(np.ones(4) + (np.arange(4) == c) * 2)

    stacker = StackingEnsemble(classes=CLASSES, n_folds=5, meta='logistic_regression')
    stacker.fit_meta({'logistic': oof_a, 'xgboost': oof_b}, labels)

    # Now predict with xgboost missing — should fill with uniform and still produce
    # a valid probability matrix
    preds = stacker.predict_proba({'logistic': oof_a[:5], 'xgboost': None})
    assert preds.shape == (5, 4)
    assert np.allclose(preds.sum(axis=1), 1.0, atol=1e-5)
