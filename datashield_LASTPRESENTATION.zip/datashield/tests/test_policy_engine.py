"""
test_policy_engine.py
---------------------
Unit tests for the Policy Engine.

Covers:
  - Regex detection for each PII type
  - Luhn check rejects invalid credit-card-shaped numbers
  - High-severity PII forces Restricted
  - Multiple medium-severity PII aggregates to Restricted
  - Threshold rules
  - Confidential keyword bumps Internal -> Confidential
  - Action mapping
  - Low-confidence triggers HumanReview
"""
import os
import sys
import pytest

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from policy_engine.rules import PolicyEngine, luhn_valid


CONFIG_PATH = os.path.join(os.path.dirname(__file__), '..', 'configs', 'policy.yaml')


@pytest.fixture(scope='module')
def engine():
    return PolicyEngine(CONFIG_PATH)


# ------------------------------------------------------------
# Luhn check
# ------------------------------------------------------------
def test_luhn_valid_known_good():
    # These are Visa/MC test numbers (all satisfy Luhn)
    assert luhn_valid('4539148803436467') is True
    assert luhn_valid('5500000000000004') is True
    assert luhn_valid('4111111111111111') is True


def test_luhn_rejects_invalid():
    assert luhn_valid('1234567812345678') is False
    assert luhn_valid('0000000000000000') is True  # edge: all zeros is technically valid
    assert luhn_valid('123') is False               # too short


# ------------------------------------------------------------
# PII regex detection
# ------------------------------------------------------------
def test_detects_ssn(engine):
    hits = engine.scan_pii('My SSN is 123-45-6789 please be careful')
    names = [h.rule_name for h in hits]
    assert 'PII_REGEX_SSN' in names


def test_detects_valid_credit_card(engine):
    # 4539148803436467 is Luhn-valid
    hits = engine.scan_pii('Card: 4539 1488 0343 6467')
    names = [h.rule_name for h in hits]
    assert 'PII_REGEX_CREDIT_CARD' in names


def test_rejects_invalid_credit_card_via_luhn(engine):
    # Luhn-invalid 16-digit string should NOT be flagged as credit card
    hits = engine.scan_pii('Tracking number: 1234 5678 1234 5678')
    cc_hits = [h for h in hits if h.rule_name == 'PII_REGEX_CREDIT_CARD']
    assert len(cc_hits) == 0


def test_detects_iban(engine):
    hits = engine.scan_pii('Transfer to IBAN GB29ABCD12345678901234 today')
    names = [h.rule_name for h in hits]
    assert 'PII_REGEX_IBAN' in names


def test_detects_indian_pan(engine):
    hits = engine.scan_pii('PAN card: ABCDE1234F attached')
    names = [h.rule_name for h in hits]
    assert 'PII_REGEX_PAN_INDIA' in names


def test_detects_aadhaar(engine):
    hits = engine.scan_pii('Aadhaar number 1234 5678 9012')
    names = [h.rule_name for h in hits]
    assert 'PII_REGEX_AADHAAR' in names


def test_detects_email_as_medium_severity(engine):
    hits = engine.scan_pii('Contact me at john.doe@example.com')
    email_hits = [h for h in hits if h.rule_name == 'PII_REGEX_EMAIL']
    assert len(email_hits) == 1
    assert email_hits[0].severity == 'medium'


# ------------------------------------------------------------
# Masking — no raw PII returned
# ------------------------------------------------------------
def test_matched_value_is_masked(engine):
    raw = '123-45-6789'
    hits = engine.scan_pii(f'SSN is {raw}')
    assert all(raw not in h.matched_value_masked for h in hits)
    assert all('*' in h.matched_value_masked for h in hits)


# ------------------------------------------------------------
# Apply() — full policy decision
# ------------------------------------------------------------
def test_high_severity_pii_forces_restricted(engine):
    probs = {'Public': 0.8, 'Internal': 0.1, 'Confidential': 0.05, 'Restricted': 0.05}
    decision = engine.apply('SSN 123-45-6789 on file', pre_policy_label='Public',
                            class_probabilities=probs)
    assert decision.post_policy_label == 'Restricted'
    assert decision.action == 'Quarantine'
    assert any('PII_REGEX_SSN' in r for r in decision.triggered_rules)


def test_multiple_medium_pii_aggregate_to_restricted(engine):
    # Email + phone = 2 medium hits >= threshold → Restricted
    text = 'Email john@example.com phone (555) 123-4567'
    probs = {'Public': 0.6, 'Internal': 0.2, 'Confidential': 0.15, 'Restricted': 0.05}
    decision = engine.apply(text, pre_policy_label='Public', class_probabilities=probs)
    assert decision.post_policy_label == 'Restricted'


def test_threshold_override_to_restricted(engine):
    # No PII but model is very confident in Restricted
    probs = {'Public': 0.05, 'Internal': 0.1, 'Confidential': 0.1, 'Restricted': 0.75}
    decision = engine.apply('generic text without pii patterns',
                            pre_policy_label='Restricted', class_probabilities=probs)
    assert decision.post_policy_label == 'Restricted'


def test_internal_bumped_to_confidential_by_keyword(engine):
    probs = {'Public': 0.1, 'Internal': 0.85, 'Confidential': 0.03, 'Restricted': 0.02}
    decision = engine.apply('Employee compensation discussion notes.',
                            pre_policy_label='Internal', class_probabilities=probs)
    assert decision.post_policy_label == 'Confidential'
    assert any('KEYWORD_CONFIDENTIAL' in r for r in decision.triggered_rules)


def test_low_confidence_triggers_human_review(engine):
    probs = {'Public': 0.3, 'Internal': 0.3, 'Confidential': 0.2, 'Restricted': 0.2}
    decision = engine.apply('ambiguous short text',
                            pre_policy_label='Public', class_probabilities=probs)
    assert decision.action == 'HumanReview'
    assert any('LOW_CONFIDENCE' in r for r in decision.triggered_rules)


def test_public_text_gets_allow_action(engine):
    probs = {'Public': 0.9, 'Internal': 0.05, 'Confidential': 0.03, 'Restricted': 0.02}
    decision = engine.apply('Press release about our latest product launch.',
                            pre_policy_label='Public', class_probabilities=probs)
    assert decision.post_policy_label == 'Public'
    assert decision.action == 'Allow'


def test_decision_to_dict_is_json_safe(engine):
    import json
    probs = {'Public': 0.1, 'Internal': 0.1, 'Confidential': 0.1, 'Restricted': 0.7}
    decision = engine.apply('SSN 123-45-6789', pre_policy_label='Restricted',
                            class_probabilities=probs)
    d = decision.to_dict()
    # Must be JSON-serializable without error
    json.dumps(d)
    assert 'pre_policy_label' in d
    assert 'post_policy_label' in d
    assert 'triggered_rules' in d
    assert 'action' in d
