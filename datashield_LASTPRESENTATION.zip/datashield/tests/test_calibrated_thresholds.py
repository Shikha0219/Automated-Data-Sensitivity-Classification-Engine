"""
test_calibrated_thresholds.py
-----------------------------
Tests for the data-driven threshold calibration feature.

Validates:
  - Calibration metadata exists in policy.yaml
  - Calibrated thresholds are within valid ranges
  - PolicyDecision includes calibration_source in its trace
  - Thresholds produce valid policy decisions (no regressions)

Run: pytest tests/test_calibrated_thresholds.py -v
"""
import os
import sys
import json
import pytest
import yaml

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from policy_engine.rules import PolicyEngine


CONFIG_PATH = os.path.join(os.path.dirname(__file__), '..', 'configs', 'policy.yaml')


@pytest.fixture(scope='module')
def engine():
    return PolicyEngine(CONFIG_PATH)


@pytest.fixture(scope='module')
def policy_config():
    with open(CONFIG_PATH, 'r', encoding='utf-8') as f:
        return yaml.safe_load(f)


# ----------------------------------------------------------------
# Calibration metadata presence
# ----------------------------------------------------------------
class TestCalibrationMetadata:
    def test_calibration_metadata_exists(self, policy_config):
        """Policy.yaml must have a calibration_metadata section."""
        assert 'calibration_metadata' in policy_config, \
            'calibration_metadata section missing from policy.yaml'

    def test_calibration_method_specified(self, policy_config):
        """Calibration method must be documented."""
        meta = policy_config['calibration_metadata']
        assert 'method' in meta
        assert meta['method'] == 'precision_recall_sweep'

    def test_calibration_dataset_specified(self, policy_config):
        """Dataset used for calibration must be documented."""
        meta = policy_config['calibration_metadata']
        assert 'dataset' in meta
        assert 'synthetic_dataset' in meta['dataset']

    def test_calibration_description_present(self, policy_config):
        """Description explaining data-driven approach must be present."""
        meta = policy_config['calibration_metadata']
        assert 'description' in meta
        desc = meta['description'].lower()
        # Must mention data-driven / not hand-picked
        assert 'data-driven' in desc or 'not hand-picked' in desc or 'precision-recall' in desc

    def test_calibration_script_referenced(self, policy_config):
        """The calibration script path must be documented."""
        meta = policy_config['calibration_metadata']
        assert 'calibration_script' in meta
        assert 'calibrate_thresholds' in meta['calibration_script']


# ----------------------------------------------------------------
# Threshold values are valid
# ----------------------------------------------------------------
class TestThresholdValues:
    def test_thresholds_section_exists(self, policy_config):
        assert 'thresholds' in policy_config

    def test_restricted_override_prob_in_range(self, policy_config):
        val = policy_config['thresholds']['restricted_override_prob']
        assert 0.3 <= val <= 0.95, f'restricted_override_prob={val} out of valid range'

    def test_confidential_escalate_prob_in_range(self, policy_config):
        val = policy_config['thresholds']['confidential_escalate_prob']
        assert 0.3 <= val <= 0.95, f'confidential_escalate_prob={val} out of valid range'

    def test_low_confidence_prob_in_range(self, policy_config):
        val = policy_config['thresholds']['low_confidence_prob']
        assert 0.2 <= val <= 0.80, f'low_confidence_prob={val} out of valid range'

    def test_restricted_threshold_below_confidential(self, policy_config):
        """Restricted threshold should be ≤ confidential threshold (makes sense semantically)."""
        t = policy_config['thresholds']
        # restricted_override_prob should generally be ≤ confidential_escalate_prob
        # because we want to catch Restricted at a lower bar
        assert t['restricted_override_prob'] <= t['confidential_escalate_prob'] + 0.15, \
            'restricted threshold is unreasonably higher than confidential threshold'


# ----------------------------------------------------------------
# PolicyDecision includes calibration_source
# ----------------------------------------------------------------
class TestCalibrationInDecisions:
    def test_calibration_source_in_policy_decision(self, engine):
        """Every PolicyDecision must include calibration_source."""
        probs = {'Public': 0.8, 'Internal': 0.1, 'Confidential': 0.05, 'Restricted': 0.05}
        decision = engine.apply('Test text for calibration trace.', 'Public', probs)
        assert decision.calibration_source is not None, \
            'calibration_source missing from PolicyDecision'

    def test_calibration_source_in_to_dict(self, engine):
        """calibration_source must appear in the serialized decision dict."""
        probs = {'Public': 0.8, 'Internal': 0.1, 'Confidential': 0.05, 'Restricted': 0.05}
        decision = engine.apply('Test text.', 'Public', probs)
        d = decision.to_dict()
        assert 'calibration_source' in d
        assert d['calibration_source'] is not None

    def test_calibration_source_is_json_serializable(self, engine):
        """calibration_source must be JSON-safe for audit logging."""
        probs = {'Public': 0.5, 'Internal': 0.3, 'Confidential': 0.1, 'Restricted': 0.1}
        decision = engine.apply('JSON test.', 'Public', probs)
        d = decision.to_dict()
        # Must not raise
        json.dumps(d)

    def test_calibration_source_has_method(self, engine):
        """calibration_source.method must reference the calibration approach."""
        probs = {'Public': 0.9, 'Internal': 0.05, 'Confidential': 0.03, 'Restricted': 0.02}
        decision = engine.apply('Method test.', 'Public', probs)
        assert 'method' in decision.calibration_source


# ----------------------------------------------------------------
# Functional regression tests — calibrated thresholds still work
# ----------------------------------------------------------------
class TestCalibratedThresholdsFunctional:
    def test_high_pii_still_forces_restricted(self, engine):
        """PII regex must still override to Restricted regardless of thresholds."""
        probs = {'Public': 0.9, 'Internal': 0.05, 'Confidential': 0.03, 'Restricted': 0.02}
        decision = engine.apply('SSN 123-45-6789 on file.', 'Public', probs)
        assert decision.post_policy_label == 'Restricted'
        assert decision.action == 'Quarantine'

    def test_restricted_threshold_override_works(self, engine):
        """When P(Restricted) exceeds calibrated threshold, label is overridden."""
        probs = {'Public': 0.05, 'Internal': 0.05, 'Confidential': 0.1, 'Restricted': 0.80}
        decision = engine.apply('No PII but high restricted prob.', 'Restricted', probs)
        assert decision.post_policy_label == 'Restricted'
        assert decision.action == 'Quarantine'

    def test_low_confidence_still_triggers_human_review(self, engine):
        """Low confidence must still route to HumanReview."""
        probs = {'Public': 0.30, 'Internal': 0.30, 'Confidential': 0.20, 'Restricted': 0.20}
        decision = engine.apply('Ambiguous text.', 'Public', probs)
        assert decision.action == 'HumanReview'

    def test_public_high_confidence_gets_allow(self, engine):
        """High-confidence Public must get Allow action."""
        probs = {'Public': 0.92, 'Internal': 0.04, 'Confidential': 0.02, 'Restricted': 0.02}
        decision = engine.apply('Public press release announcement.', 'Public', probs)
        assert decision.post_policy_label == 'Public'
        assert decision.action == 'Allow'

    def test_keyword_still_bumps_internal_to_confidential(self, engine):
        """Confidential keywords must still bump Internal → Confidential."""
        probs = {'Public': 0.05, 'Internal': 0.85, 'Confidential': 0.05, 'Restricted': 0.05}
        decision = engine.apply('Employee salary compensation details.', 'Internal', probs)
        assert decision.post_policy_label == 'Confidential'
