"""
feature_engineering/metadata_features.py
----------------------------------------
Metadata one-hot vocab used by the XGBoost feature matrix.

These constants WERE inside models/xgboost_model.py. Moved here so the
feature layer owns them and XGBoost imports from here. Same numbers
serve inference AND the UI inspection view.

Vocab is frozen — changing values invalidates trained joblibs.
"""
from __future__ import annotations
from typing import Dict, List

SOURCE_SYSTEMS = [
    'JIRA', 'ServiceNow', 'Confluence', 'Workday', 'Salesforce',
    'Gmail', 'SharePoint', 'UNKNOWN',
]
DEPARTMENTS = [
    'Engineering', 'HR', 'Finance', 'Legal', 'Sales', 'Marketing',
    'Operations', 'UNKNOWN',
]
FILE_TYPES = [
    'txt', 'email', 'ticket', 'doc', 'note', 'csv', 'json', 'log',
    'md', 'UNKNOWN',
]


def _onehot(value, vocab: List[str]) -> List[int]:
    v = value if value in vocab else 'UNKNOWN'
    return [1 if x == v else 0 for x in vocab]


def metadata_vector(metadata: Dict[str, str]) -> List[int]:
    """Concatenated one-hot: [source_system | department | file_type].

    The order is FIXED and matches the trained XGBoost feature matrix.
    """
    m = metadata or {}
    return (
        _onehot(m.get('source_system') or 'UNKNOWN', SOURCE_SYSTEMS)
        + _onehot(m.get('department') or 'UNKNOWN', DEPARTMENTS)
        + _onehot(m.get('file_type') or 'UNKNOWN', FILE_TYPES)
    )


def metadata_feature_dict(metadata: Dict[str, str]) -> Dict[str, int]:
    """Same vector, but as a labelled {name: 0/1} dict for the UI."""
    vec = metadata_vector(metadata)
    names = (
        [f'src_{s}' for s in SOURCE_SYSTEMS]
        + [f'dept_{d}' for d in DEPARTMENTS]
        + [f'ft_{t}' for t in FILE_TYPES]
    )
    return dict(zip(names, vec))


def metadata_vector_size() -> int:
    return len(SOURCE_SYSTEMS) + len(DEPARTMENTS) + len(FILE_TYPES)
