"""
feature_engineering
===================
Centralized, reusable feature layer.

WHAT MOVED IN HERE
------------------
Previously each layer recomputed its own version of tokens, n-grams,
numeric stats, and metadata one-hots. Now every consumer pulls from this
package:

  - shared tokenization                 → feature_engineering.tokenization
  - shared TF-IDF vectorizer access     → feature_engineering.vectorizers
  - shared metadata encoders            → feature_engineering.metadata_features
  - optional transformer embeddings     → feature_engineering.vectorizers
  - LRU cache for repeated documents    → feature_engineering.cache
  - unified FeatureSummary schema       → feature_engineering.schemas

WHO CONSUMES IT
---------------
  - api.py                  /features/preview, embedded in /classify response
  - models/xgboost_model    inference _featurize() pulls numeric+metadata vectors
  - models/logistic_model   indirectly (its pipeline holds the TF-IDF we expose)
  - ui/components/          renders FeatureSummary.to_dict()

PUBLIC API
----------
  featurize(text, lang, top_k, metadata)   → FeatureSummary (the main entry)
  build_inference_features(...)            → (text_features_callable, numeric_vec, meta_vec)
  FeatureSummary                            (shared dataclass)
  tokenize(text)                            (shared tokenizer)
  numeric_text_stats_vector(text)           (stable-order numeric vector)
  metadata_vector(metadata)                 (stable-order one-hot vector)
"""
from __future__ import annotations
from typing import Any, Dict, List, Optional, Tuple

# Re-export shared schema + helpers so callers can do
#   from feature_engineering import featurize, FeatureSummary, tokenize
from feature_engineering.schemas import FeatureSummary
from feature_engineering.tokenization import (
    tokenize,
    ngram_counts,
    numeric_text_stats,
    numeric_text_stats_vector,
    NUMERIC_FEATURE_ORDER,
)
from feature_engineering.metadata_features import (
    metadata_vector,
    metadata_feature_dict,
    metadata_vector_size,
)
from feature_engineering.vectorizers import (
    tfidf_top_tokens,
    tfidf_vocab_size,
    get_tfidf_vectorizer,
    get_logistic_model,
    get_transformer_model,
    embedding_stats,
)
from feature_engineering import cache as _cache


# ─────────────────────────────────────────────────────────────
# Inspection entry point — used by /features/preview and /classify
# ─────────────────────────────────────────────────────────────

def featurize(
    text: str,
    lang: str = 'en',
    top_k: int = 10,
    metadata: Optional[Dict[str, Any]] = None,
    use_cache: bool = True,
) -> FeatureSummary:
    """Build a FeatureSummary for one document.

    Backwards-compatible with the old single-file module: existing callers
    keep working with no edits.

    `metadata` is optional; when provided, one-hot metadata features are
    included so the UI can show what XGBoost actually consumes.
    """
    if not text:
        return FeatureSummary(used_language=lang)

    if use_cache:
        cached = _cache.get(text, lang, top_k)
        if cached is not None:
            # Refresh metadata features (cheap) on the cached object
            if metadata is not None:
                cached.metadata_features = metadata_feature_dict(metadata)
            cached.cache_hit = True
            return cached

    uni, bi = ngram_counts(text)
    summary = FeatureSummary(
        tfidf_top=tfidf_top_tokens(text, lang=lang, top_k=top_k),
        unigram_count=uni,
        bigram_count=bi,
        numeric_features=numeric_text_stats(text),
        metadata_features=metadata_feature_dict(metadata or {}) if metadata is not None else {},
        vocab_size=tfidf_vocab_size(lang),
        used_language=lang,
        cache_hit=False,
    )

    embed = embedding_stats(text, lang=lang)
    if embed is not None:
        summary.embedding_dim = embed.get('embedding_dim')
        summary.embedding_norm = embed.get('embedding_norm')

    if use_cache:
        _cache.put(text, lang, top_k, summary)
    return summary


# ─────────────────────────────────────────────────────────────
# Inference entry point — used by models/xgboost_model._featurize
# ─────────────────────────────────────────────────────────────

def build_inference_numeric_vector(text: str) -> List[float]:
    """Stable-order numeric vector for model consumption. Same numbers
    that show up in FeatureSummary.numeric_features."""
    return numeric_text_stats_vector(text)


def build_inference_metadata_vector(metadata: Dict[str, Any]) -> List[int]:
    """One-hot metadata vector for model consumption. Same numbers
    that show up in FeatureSummary.metadata_features."""
    return metadata_vector(metadata)


def cache_stats() -> dict:
    """Expose feature-cache stats for the MLOps dashboard."""
    return _cache.stats()


__all__ = [
    'FeatureSummary',
    'featurize',
    'tokenize',
    'ngram_counts',
    'numeric_text_stats',
    'numeric_text_stats_vector',
    'metadata_vector',
    'metadata_feature_dict',
    'metadata_vector_size',
    'tfidf_top_tokens',
    'tfidf_vocab_size',
    'embedding_stats',
    'build_inference_numeric_vector',
    'build_inference_metadata_vector',
    'cache_stats',
]
