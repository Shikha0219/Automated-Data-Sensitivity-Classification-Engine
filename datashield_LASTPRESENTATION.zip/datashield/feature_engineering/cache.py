"""
feature_engineering/cache.py
----------------------------
Small in-memory LRU cache for FeatureSummary objects keyed by a
fast hash of (text + lang). Useful for two scenarios:

  1. The UI calls /preprocess/preview and then /features/preview for
     the SAME text — both run featurize() under the hood, so the second
     call hits the cache.
  2. Batch jobs that re-classify after a label correction don't redo
     the vectorization.

Bounded size; never grows beyond MAX_ENTRIES.
"""
from __future__ import annotations
import hashlib
from collections import OrderedDict
from threading import Lock
from typing import Optional, Any

MAX_ENTRIES = 256

_cache: 'OrderedDict[str, Any]' = OrderedDict()
_lock = Lock()


def _key(text: str, lang: str, top_k: int) -> str:
    h = hashlib.sha1(f'{lang}|{top_k}|{text}'.encode('utf-8', errors='replace')).hexdigest()
    return h


def get(text: str, lang: str, top_k: int) -> Optional[Any]:
    k = _key(text, lang, top_k)
    with _lock:
        if k in _cache:
            # LRU touch
            _cache.move_to_end(k)
            return _cache[k]
    return None


def put(text: str, lang: str, top_k: int, value: Any) -> None:
    k = _key(text, lang, top_k)
    with _lock:
        _cache[k] = value
        _cache.move_to_end(k)
        while len(_cache) > MAX_ENTRIES:
            _cache.popitem(last=False)


def stats() -> dict:
    with _lock:
        return {'entries': len(_cache), 'capacity': MAX_ENTRIES}


def clear() -> None:
    with _lock:
        _cache.clear()
