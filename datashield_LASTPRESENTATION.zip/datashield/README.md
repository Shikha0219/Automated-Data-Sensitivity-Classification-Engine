# DataShield — Sensitivity Classification Engine

An enterprise reference platform for **automated data-sensitivity classification** of unstructured text documents (customer tickets, HR records, financial documents, contracts, emails). Built against the PS-01 problem statement.

Runs entirely on a laptop — **no Kafka, no Docker, no Kubernetes, no S3, no cloud calls.**

> Classifies any document into one of **Public / Internal / Confidential / Restricted**, returns confidence + evidence + policy action, masks PII before audit, logs every decision, exposes a human-in-the-loop correction path, and ships with lightweight MLOps (model registry, drift monitoring, retraining workflow).

---

## Quick start

**Prerequisites:** Python 3.10+ and Node.js 18+ (for the React UI).

```bash
# 1. Install Python deps
pip install -r requirements.txt

# 2. (One-time) install UI deps
cd ui && npm install && npm run build && cd ..

# 3. Start API + UI with a single command
python run.py
```

Then open:
- **UI:** http://localhost:8501
- **API docs (Swagger):** http://localhost:8000/docs

To stop: `Ctrl+C`.

---

## What's in the box

| Capability | Implementation |
|---|---|
| Backend | FastAPI + Uvicorn |
| Frontend | React 18 + TypeScript + Vite + Tailwind CSS + Recharts + Lucide icons |
| Models | scikit-learn (Logistic Regression) + XGBoost + optional DistilBERT |
| Ensemble | Soft voting + stacking meta-learner |
| Explainability | SHAP + LIME + Integrated Gradients |
| PII masking | Presidio (primary) + regex (defensive fallback) |
| Policy | Configurable rule overlay (`configs/policy.yaml`) with dual-approval gate |
| Multilingual | Language detection → English / Hindi model sets |
| MLOps | MLflow experiment tracking · Evidently-style drift report · monthly + drift-based retraining triggers |

---

## Architecture

```
            ┌─────────────────────────────────────────────────────┐
            │   React UI (Vite dev server on :8501)               │
            │   - Classify (upload / paste / async batch)         │
            │   - History  (audit + HITL corrections)             │
            │   - Approvals (Legal + DataGov sign-off)            │
            │   - MLOps    (registry, drift, retraining, audit)   │
            └────────────────────┬────────────────────────────────┘
                                 │  /api/*  (proxied)
                                 ▼
            ┌─────────────────────────────────────────────────────┐
            │   FastAPI app (api.py) on :8000                     │
            │   /classify, /classify/file, /classify/batch        │
            │   /preprocess/preview, /features/preview            │
            │   /history, /document/{id}, /override, /review-queue│
            │   /approval/sign-off, /approval/status/{id}         │
            │   /mlops/registry · /mlops/drift · /mlops/audit     │
            │   /mlops/retraining · /mlops/retrain                │
            │   /metrics · /health                                │
            └────────────────────┬────────────────────────────────┘
                                 ▼
   ┌────────────────────────────────────────────────────────────────┐
   │  Layer 1: ingestion.py        PDF/DOCX/TXT/CSV/JSON/HTML/LOG   │
   │  Layer 2: preprocessing.py    Clean + mask + tokenize + meta   │
   │  Layer 3: feature_engineering/   SHARED & REUSABLE             │
   │     ├── tokenization.py       single-source-of-truth tokenizer │
   │     ├── vectorizers.py        lazy LRU-cached TF-IDF / embed   │
   │     ├── metadata_features.py  frozen one-hot vocab             │
   │     ├── cache.py              feature LRU cache                │
   │     └── schemas.py            FeatureSummary contract          │
   │  Layer 4: models/*.py         LR + XGBoost + Transformer       │
   │  Layer 5: ensemble/*.py       Voting / Stacking                │
   │  Layer 6: explainability/*.py SHAP / LIME / IG                 │
   │  Layer 7: policy_engine/*.py  Rule overlay + approval gate     │
   │  Cross-cutting:                                                │
   │     pipeline.py               orchestrates Layers 2-7           │
   │     mlops.py                  registry + drift + retraining     │
   │     active_learning.py        override → retraining loop        │
   └────────────────────────────────────────────────────────────────┘
```

The pre-trained joblib artifacts for English + Hindi ship in `artifacts/`. **No training step is required for the demo.** To retrain from scratch: `python scripts/train_all.py`.

---

## Async batch processing (folders, ZIPs, recursion)

The Classify → **Async batch** tab supports three input sources:

1. **Files** — multi-select any combination of supported formats.
2. **Folder** — uses the browser's `webkitdirectory` so an entire folder tree is uploaded with relative paths preserved. The server processes every file in every subdirectory.
3. **ZIP archive** — auto-extracted server-side, recursive scan inside. macOS metadata folders (`__MACOSX`) and hidden files are filtered out automatically.

The UI auto-polls job status every 1.5 seconds and shows per-file progress (`queued / running / done / failed`) plus the final label and policy action for each file.

```bash
# Equivalent CLI flow
curl -X POST http://localhost:8000/classify/batch \
  -F "files=@docs.zip" \
  -F "files=@another.pdf"
# → { "job_id": "...", "expanded_from_zip": 12 }

curl http://localhost:8000/classify/status/<job_id>
```

---

## Shared feature engineering layer

The PS calls Feature Engineering out as its own component, but the previous prototype kept feature logic duplicated inside each model. The new `feature_engineering/` package is the **single source of truth**:

```python
from feature_engineering import (
    featurize,                            # full FeatureSummary for UI / API
    tokenize,                             # canonical word tokenizer
    numeric_text_stats_vector,            # stable-order numeric vector
    metadata_vector,                      # one-hot metadata vector
    build_inference_numeric_vector,       # used by XGBoost at inference
    build_inference_metadata_vector,      # used by XGBoost at inference
    tfidf_top_tokens, tfidf_vocab_size,   # introspection of the trained TF-IDF
    embedding_stats,                      # optional transformer stats
    cache_stats, FeatureSummary,
)
```

`models/xgboost_model.py` now imports the shared `build_inference_*_vector` helpers — same numbers serve **inference** AND the UI **inspection** view. `lru_cache` keeps the trained `TfidfVectorizer` warm across requests. A small in-memory LRU keeps `FeatureSummary` objects cached for repeat documents.

---

## MLOps capabilities

Open the **MLOps** tab in the UI for:

| Sub-tab | Backed by |
|---|---|
| Overview | `/metrics`, `/mlops/registry`, `/mlops/drift`, `/mlops/retraining` |
| Model registry | `/mlops/registry` (champion / challenger / history) |
| Drift | `/mlops/drift` (PSI on label distribution + confidence drop) — also writes a full Evidently HTML report at `logs/drift_report.html` when `evidently` is installed; otherwise serves a fallback HTML view at `/mlops/drift/report.html`. |
| Retraining | `/mlops/retraining` + `/mlops/retrain` (queues a retraining request, prints the exact CLI to run) |
| Audit log | `/mlops/audit` reads the last N entries from `logs/audit.jsonl` |

**MLflow** experiment tracking is integrated via `mlops.log_experiment()`, with a SQLite backend at `logs/mlruns.db` if `mlflow` is installed; otherwise falls back to JSONL logging in `logs/experiments.jsonl`.

---

## API surface

```
Health
  GET  /health
  GET  /metrics

Classification
  POST /classify             — JSON text → ClassificationResult
  POST /classify/file        — multipart file (any supported format)
  POST /classify/batch       — multipart files (folders + ZIPs auto-handled)
  GET  /classify/status/{job_id}

Inspection (Layer 2 + 3 previews — no classification side-effect)
  POST /preprocess/preview
  POST /features/preview

Audit & history
  GET  /history?limit=&offset=&label=&only_overrides=
  GET  /document/{doc_id}

Human-in-the-loop
  POST /override
  GET  /review-queue

Approvals (Constraint C4 — dual sign-off for Restricted data)
  POST /approval/sign-off
  GET  /approval/status/{doc_id}

MLOps
  GET  /mlops/registry
  GET  /mlops/drift
  GET  /mlops/drift/report.html
  GET  /mlops/audit?limit=
  GET  /mlops/retraining
  POST /mlops/retrain
  POST /mlops/export-batch
```

---

## Folder structure

```
datashield/
├── api.py                       — FastAPI app (single file, focused)
├── pipeline.py                  — Layer 2-7 orchestrator
├── ingestion.py                 — Layer 1 (PDF/DOCX/TXT/CSV/JSON/HTML)
├── preprocessing.py             — Layer 2 (clean, mask, tokenize, metadata)
├── feature_engineering/         — Layer 3 (shared & reusable)
│   ├── __init__.py
│   ├── tokenization.py
│   ├── vectorizers.py
│   ├── metadata_features.py
│   ├── cache.py
│   └── schemas.py
├── models/                      — Layer 4 (LR + XGBoost + Transformer)
├── ensemble/                    — Layer 5 (voting + stacking)
├── explainability/              — Layer 6 (SHAP + LIME + IG)
├── policy_engine/               — Layer 7 (rules + approval gate)
├── mlops.py                     — registry + drift + retraining
├── active_learning.py           — override → retraining loop
├── configs/                     — model.yaml, policy.yaml
├── artifacts/                   — pre-trained joblibs (en, hi)
├── data/                        — synthetic dataset + sample_docs/
├── logs/                        — audit.jsonl, jobs/, drift_report.*, overrides.jsonl
├── scripts/                     — train_all.py, predict_cli.py, evaluate, benchmark
├── tests/                       — pytest suite
├── ui/                          — React + TS + Vite + Tailwind frontend
└── run.py                       — one-command launcher
```

---

## Constraints + design choices

- **C1 — No raw PII persists:** `preprocessing.preprocess()` returns three views (raw / clean / masked); only the masked view ever flows into `logs/audit.jsonl`.
- **C2 — Auditable, no black-box-only:** every prediction carries SHAP + LIME (+ IG) evidence tokens; the LR baseline + policy overlay are fully white-box.
- **C3 — Air-gapped support:** zero outbound network calls. Optional transformer and Evidently degrade gracefully when not installed.
- **C4 — Dual approval:** Legal + DataGov sign-off enforced via the Approvals tab + `/approval/sign-off`.
- **C5 — mTLS-ready:** FastAPI behind any TLS-terminating reverse proxy (nginx / Traefik) when deployed.

---

## Removed in this iteration

- All webhook functionality (subscription CRUD, HMAC-signed delivery, retry, deliveries log). The orchestrator no longer fires outbound HTTP. Operators consume the audit log + `/metrics` directly.

## License

Internal reference platform. Not for redistribution.
